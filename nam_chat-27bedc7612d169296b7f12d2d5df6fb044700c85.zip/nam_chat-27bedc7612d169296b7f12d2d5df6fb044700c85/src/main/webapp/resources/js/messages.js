/**
 * 
 */
'use strict';
$(document).ready(function() {
	var stomp = '';
	var messages = '';
	var token = $('#_csrf').attr('content');
	var header = $('#_csrf_header').attr('content');
	var groupid = $('.channelid').attr("data-id");
	console.log($('.channelid').attr("data-id"));
	(function update() {
		$.ajax({
			url : '/listMessages',
			type : 'GET',
			dataType : 'json',
			data : 'groups='+ $('.channelid').attr("data-id"),
			processData : false,
			contentType : 'application/json',
			beforeSend : function(xhr) {
				xhr.setRequestHeader(header, token);
			},
			success : function(data) {
				var message =data.messagesresult;
				var messageout=document.getElementById("messagelist");
				var messagelist="";
				for(var i=0;i<message.length;i++){
					if (message[i].sessionimage != null){
						messagelist +=('<div class="layout-tool">'
								+ '<label class="from-note">'
								+ message[i].userchat
								+ '</label>'
								+'<div class="messages">'
								+'<img class="imagemessages" src=/resources/image/'+message[i].sessionimage+'>'
								+'</div>'
								+'<div class="messageborder">'
								+'</div>'
								+'</div>');
					} if(message[i].session != null){
					messagelist +=('<div class="layout-tool">'
							+ '<label class="from-note">'
							+ message[i].userchat
							+ '</label>'
							+'<div class="messages">'
							+ message[i].session
							+'</div>'
							+'<div class="messageborder">'
							+'</div>'
							+'</div>');
						}
					}
				messageout.innerHTML=messagelist;
				}
			})
	})();
	$('.message-list').scroll(function (){
		if($('.message-list').scrollTop() == 0){
			$.ajax({
				url:'/listnextMessages',
				type :'POST',
				dataType: 'json',
				data: 'groups='+ $('.channelid').attr("data-id"),
				processData: false,
				beforeSend : function(xhr) {
					xhr.setRequestHeader(header, token);
				},
				success : function(data) {
					var message =data.messagesresult;
					var messageout=document.getElementById("messagelist");
					var messagelist="";
					for(var i=0;i<message.length;i++){
						if (message[i].sessionimage != null){
							$("#messagelist").prepend("<div class='layout-tool'><label class='from-note'>"
									+ message[i].userchat+"</label><div class='messages'><img class='imagemessages' src=/resources/image/"
									+message[i].sessionimage+"></div><div class='messageborder'>"
									+"</div></div>");
						} if(message[i].session != null){
							$("#messagelist").prepend("<div class='layout-tool'><label class='from-note'>"+message[i].userchat
									+"</label><div class='messages'>"+ message[i].session+
									"</div><div class='messageborder'></div></div>");
						}
					}
				}
			})
		}
	});
	var bottom =$('.message-list');
	var height =bottom.get(0).scrollHeight;
	bottom.animate({scrollTop: height});
	/*
	$('#data').keyup(function(e) {
		var groupid = $('.channelid').attr("data-id");
		if(e.keyCode == 13){
			$.ajax({
				url : '/postMessages',
				type : 'GET',
				dataType : 'json',
				data : $('#data').serialize()+'&channelid='+ groupid,
				processData : false,
				contentType : 'application/json',
				beforeSend : function(xhr) {
					xhr.setRequestHeader(header, token);
				},
				success : function(data) {
					var message =data.messagesresult;
					$("#messagelist").append("<div class='layout-tool'><label class='from-note'>"+message[0].userchat+"</label><div class='messages'> "
							+message[0].session+
									"</div><div class='messageborder'></div></div>");
					$(".data_input").val('');
					$('.message-list').scrollTop ($('.message-list')[0].scrollHeight) ;
				}
			})
		}
	})*/
	function sendMessages(){
		var messagesdata = $('#data').val();
		var groupid = $('.channelid').attr("data-id");
		var dataname= $('.dataname').attr("data-name");
		var messagesResult = {session: messagesdata, groupid: groupid,userchats: dataname};
		stomp.send('/app/sendMessages',{token:token},JSON.stringify(messagesResult));
		$(".data_input").val('');
		$('.message-list').scrollTop ($('.message-list')[0].scrollHeight) ;
	}
	function showMessages(data){
		var message =JSON.parse(data.body); 
		var messagelist="";
			if (message.sessionimage != null){
				messagelist +=('<div class="layout-tool">'
						+ '<label class="from-note">'
						+ message.userchat
						+ '</label>'
						+'<div class="messages">'
						+'<img class="imagemessages" src=/resources/image/'+message.sessionimage+'>'
						+'</div>'
						+'<div class="messageborder">'
						+'</div>'
						+'</div>');
			} if(message.session != null){
			messagelist +=('<div class="layout-tool">'
					+ '<label class="from-note">'
					+ message.userchat
					+ '</label>'
					+'<div class="messages">'
					+ message.session
					+'</div>'
					+'<div class="messageborder">'
					+'</div>'
					+'</div>');
				}
		$("#messagelist").append(messagelist);
		$(".data_input").val('');
		$('.message-list').scrollTop ($('.message-list')[0].scrollHeight) ;
	}
 
	var socket = new SockJS('/wsocket');
	stomp = Stomp.over(socket);
	//stomp.debug = () => {}
	stomp.connect({token:token}, function(frame) {
         //console.log('Connected: ' + frame);
         stomp.subscribe('/friend/chatroom',function(message){
        	showMessages(message);
         });
     });
	
	$('#data').keyup(function(e) {
	var groupid = $('.channelid').attr("data-id");
		if(e.keyCode == 13){
			sendMessages();
			//testMessages()
		}
	})
	$('.icon-upload').on('click', function(){
		sendMessages();
	})
})
