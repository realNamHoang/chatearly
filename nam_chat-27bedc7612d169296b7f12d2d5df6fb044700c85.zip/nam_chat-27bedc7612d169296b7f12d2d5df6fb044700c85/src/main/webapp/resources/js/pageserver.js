$(document).ready(function() {
	var token = $('#_csrf').attr('content');
	var header = $('#_csrf_header').attr('content');
	$(".saveuser").on("click", function() {
		$.ajax({
			url : '/findserver',
			type : 'POST',
			dataType : '',
			data : $('#servername').serialize(),
			processData : false,
			beforeSend : function(xhr) {
				xhr.setRequestHeader(header, token);
			},
			success : function(data) {
				var result = data.servers;
				var serverslot = $(".add-new");
				var datareturn = ('<div class="card-body contacts_body">'
									+ '<div class="d-flex bd-highlight">'
									+ '<div class="img_cont">'
									+ '<a href="${contextPath}/'
									+ result[0].serverid
									+ '"> '
									+ '<img class="user_img" src=/resources/image/'
									+ result[0].serverimage
									+ ' alt="" aria-hidden="true" width="48" height="48">'
									+ '</a>' + '</div>' + '</div>' + '</div>');
				serverslot.before(datareturn);
			}
		})
			$(".idserver").on("click", function() {
				$.ajax({
					url : '/Mappingcontroller',
					type : 'POST',
					dataType : '',
					data : $(this).attr('data-id'),
					processData : false,
					beforeSend : function(xhr) {
						xhr.setRequestHeader(header, token);
					},
					success : function(data) {
						
					}
			})
		})
	})
})