$(document).ready(function() {
			var token = $('#_csrf').attr('content');
			var header = $('#_csrf_header').attr('content');
			rolesServer = ""
			var displayRole = $('.list-role');
			var toolbar = $('.toolbar');
			var setnamerole = $('.name-role');
			$.ajax({
				url : "/ListRoleServer",
				type : 'POST',
				dataType : 'json',
				data : '',
				processData : false,
				beforeSend : function(xhr) {
					xhr.setRequestHeader(header, token);
				},
				success : function(data) {
					rolesServer = data.roleserver;
					var allrole = "";
					if (rolesServer) {
						for (var i = 0; i < rolesServer.length; i++) {
							allrole += '<label class="from-note rolenote small" name-data="'+rolesServer[i].role+'" data-id="'+rolesServer[i].id+'">' + "@"
									+ rolesServer[i].role + '</label>'
						}
						displayRole.html(allrole);
						$('.rolenote').on("click", function(){
							var setcommit="";
							setcommit=('<div class="footer-content save-file"><button class="btn color saverole" type="submit">Save Changes</button>'
							      		+'<button class="btn color-reset" type="submit">Reset</button></div>');
							toolbar.html(setcommit);
							var newrole='';
							var dataname =$(this).attr('name-data');
							var setRole=$(this);
							console.log(setRole);
							newrole =('<label class="from-note">ROLE NAME</label> '
									+'<input type="text" class="new-name-role" id="namerole" placeholder="'+dataname+'">');
							setnamerole.html(newrole);
							$('.saverole').on("click",function(){
								$.ajax({
									url : "/updateRole",
									type : 'POST',
									dataType : 'json',
									data : 'namerole='+ $('#namerole').val()+'&roleid='+setRole.attr("data-id") + '&serverid=' + $('.serverid').attr("data-id"),
									processData : false,
									beforeSend : function(xhr) {
										xhr.setRequestHeader(header, token);
									},
									success : function(data) {
									rolesServer = data.roleserver;
									var allrole = "";
									allrole = ('<label class="from-note rolenote small" name-data="'+rolesServer[0].role+'">' + "@"
											+ rolesServer[0].role + '</label>');
									displayRole.append(allrole);
									}
								})
							})
						})
					}
				}
			})
			$('.new-role').on("click", function() {
				var newrole ="";
				newrole ='<label class="from-note small rolenote" name-data="newRole">@newRole</label>';
				displayRole.append(newrole);
				$('.rolenote').on("click", function(){
					var newrole='';
					var dataname =$(this).attr('name-data');
					var setRole=$(this);
					console.log(setRole);
					newrole =('<label class="from-note">ROLE NAME</label> '
							+'<input type="text" class="new-name-role" id="namerole" placeholder="'+dataname+'">');
					setnamerole.html(newrole);
					$('.saverole').on("click",function(){
						$.ajax({
							url : "/newRole",
							type : 'POST',
							dataType : 'json',
							data : 'namerole='+ $('#namerole').val() + '&serverid=' + $('.serverid').attr("data-id"),
							processData : false,
							beforeSend : function(xhr) {
								xhr.setRequestHeader(header, token);
							},
							success : function(data) {
							rolesServer = data.roleserver;
							var allrole = "";
							allrole = ('<label class="from-note rolenote small" name-data="'+rolesServer[0].role+'">' + "@"
									+ rolesServer[0].role + '</label>');
							displayRole.append(allrole);
							}
						})
					})
				})
			})
			$('.new-role').on("click",function(){
				var setcommit="";
				setcommit=('<div class="footer-content save-file"><button class="btn color saverole" type="submit">Save Changes</button>'
				      		+'<button class="btn color-reset" type="submit">Reset</button></div>');
				toolbar.html(setcommit);
			})
		})