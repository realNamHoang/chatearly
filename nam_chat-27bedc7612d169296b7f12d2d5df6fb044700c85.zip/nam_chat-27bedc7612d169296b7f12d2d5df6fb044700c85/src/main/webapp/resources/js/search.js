$(document).ready(function() {
					var token = $('#_csrf').attr('content');
					var header = $('#_csrf_header').attr('content');
					var account="";
					$('#search').keyup(function() {
										$.ajax({
													url : "/searchUser",
													type : 'GET',
													dataType : 'json',
													data : $('#search').serialize(),
													processData : false,
													contentType : 'application/json',
													beforeSend : function(xhr) {
														xhr.setRequestHeader(header, token);
													},
													success : function(data) {
														account = data.result;
														var searchresult = document.getElementById('searchmatchemail')
														var accountdata = "";
														if (account) {
															for (var i = 0; i < account.length; i++) {
																accountdata += 
																		'<div class="friend">'
																		+ '<div class="friend-name">'
																		+ account[i].email
																		+ '</div>'
																		+ '<div id="getid">'
																		+ '#'+account[i].id
																		+ '</div>'
																		+'<div class="friend-button">'
																		+ '<button class="btn btn-sm btn-primary btn-block setfriend" type="button" data-id="'+ account[i].id+ '">'
																		+ 'Send Friend Request'
																		+ '</button>'
																		+ '</div>'
																		+ '</div>';
															searchresult.innerHTML = accountdata;
														}
														var token = $('#_csrf').attr('content');
														var header = $('#_csrf_header').attr('content');
														$('.setfriend').on("click",function() {
															var userId = $(this).attr('data-id');
																			$.ajax({
																						url : "/getid",
																						type : 'GET',
																						dataType : 'json',
																						data : 'getid='+ userId,
																						processData : false,
																						contentType : 'application/json',
																						beforeSend : function(xhr) {
																							xhr.setRequestHeader(header,token);
																						},
																						success : function(data) {
																							console.log('ready');
																							var accounts = data.result;
																							$("#friend-list").append("<div class='layout-tool'><label class='from-note'>"+accounts[0].email+"</label></div>");
																						}
																					})
																					$.ajax({
																						url : "/setgroups",
																						type : 'GET',
																						dataType : 'json',
																						data : 'getid='+ userId,
																						processData : false,
																						contentType : 'application/json',
																						beforeSend : function(xhr) {
																							xhr.setRequestHeader(header,token);
																						},
																						success : function(data) {
																							console.log('ready');
																						}
																					})
																		});
															}
														}
												})
									});
				});
$(document).on("keydown", ":input:not(textarea):not(:submit)", function(event) {
	return event.which !== 13;
});