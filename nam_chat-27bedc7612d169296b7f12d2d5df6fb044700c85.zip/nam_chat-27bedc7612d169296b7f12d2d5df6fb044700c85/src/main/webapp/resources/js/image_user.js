$(document).ready(function() {
	var file = $('.file'); 
	$(".userimage").on("click", function(e) {
		file.click();
		if ($('.file').get(0).files.length != 0) {
		var image = e.originalEvent.dataTransfer.files;
		var formImage = new FormData();
		formImage.append('image', image[0]);
		uploadFromData(formImage);
		}
	})
	function uploadFromData(formImage) {
		$.ajax({
			url : '/creatnewchannel',
			type : 'POST',
			data : formImage,
			processData : false,
			contentType : false,
			cache : false,
			beforeSend : function(xhr) {
				xhr.setRequestHeader(header, token);
			},
			success : function(data) {
				
			}
		});
	}
})