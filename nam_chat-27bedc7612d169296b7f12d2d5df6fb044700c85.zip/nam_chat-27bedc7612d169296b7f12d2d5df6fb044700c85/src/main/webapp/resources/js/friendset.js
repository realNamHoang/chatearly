$(document).ready(function() {
			console.log('ready');
			var token = $('#_csrf').attr('content');
			var header = $('#_csrf_header').attr('content');
			$.ajax({
				url : "/listFriend",
				type : 'POST',
				data:'',
				dataType : 'json',
				processData : false,
				contentType : 'application/json',
				beforeSend : function(xhr) {
					xhr.setRequestHeader(header, token);
				},
				success : function(data) {
					var account = data.result;
					var friendid = data.friendresult;
					var friendresult = document.getElementById("friend-list");
					var friendlist= "";
					for (var i = 0; i < account.length; i++) {
						if(account[i].username== null){
						friendlist += ('<div class="layout-tool">'
								+ '<label class="from-note friends" data-email="'+account[i].email+'" server-id="'+friendid[i].groupid+'">'
								+ account[i].email 
								+ '</label>'
								+ '</div>');
						}else{
							friendlist += ('<div class="layout-tool">'
									+ '<label class="from-note friends" data-email="'+account[i].email+'" server-id="'+friendid[i].groupid+'">'
									+ account[i].email 
									+ '</label>'
									+ '</div>');
						}
					}
					friendresult.innerHTML=friendlist;
						$('.friends').on("click",function() {
							var friendemail = $(this).attr('data-email');
							var groupid = $(this).attr('server-id');
							$.ajax({
								url : "/mappingDM",
								type : 'GET',
								dataType : 'json',
								data : 'friendemail='+ friendemail+'&channelid='+ groupid,
								processData : false,
								contentType : 'application/json',
								beforeSend : function(xhr) {
									xhr.setRequestHeader(header,token);
								},
								success : function(data) {
									var message =data.messagesresult;
									var messageout=document.getElementById("messagelist");
									var messagelist="";
									var serverid=document.getElementById("list-info");
									var server="";
									for(var i=0;i<message.length;i++){
										if (message[i].sessionimage != null){
											messagelist +=('<div class="layout-tool">'
													+ '<label class="from-note">'
													+ message[i].userchat
													+ '</label>'
													+'<div class="messages">'
													+'<img class="imagemessages" src=/resources/image/'+message[i].sessionimage+'>'
													+'</div>'
													+'<div class="messageborder">'
													+'</div>'
													+'</div>');
										} if(message[i].session != null){
										messagelist +=('<div class="layout-tool">'
												+ '<label class="from-note">'
												+ message[i].userchat
												+ '</label>'
												+'<div class="messages">'
												+ message[i].session
												+'</div>'
												+'<div class="messageborder">'
												+'</div>'
												+'</div>');
											}
										}
									messageout.innerHTML=messagelist;
									server +=('<label class="channelid" data-id="'+groupid+'">'+'</label>');
									serverid.innerHTML=server;
									var bottom =$('.message-list');
									var height =bottom.get(0).scrollHeight;
									bottom.animate({scrollTop: height});
								}
							})
						})
					}
				})
			})