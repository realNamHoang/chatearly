$(document)
		.ready(
				function() {
					var display = document.getElementById("displaydata");
					var put = ""
					var controll = $(".user-info");
					var token = $('#_csrf').attr('content');
					var header = $('#_csrf_header').attr('content');
					$(".data").on("click", function() {
						const check = $(this).attr("data-note")
						switch (check) {
						case 'Overview':
							break;
						case 'Moderation':
							break;
						case 'Audit Log':
							break;
						case 'Role':
							Role();
							break;
						case 'Integrations':
							break;
						case 'Emoji':
							break;
						case 'Webhooks':
							break;
						case 'Members':
							Member();
							break;
						case 'Invites':
							break;
						case 'Bans':
							break;
						}
					})
					function Role() {
						put = ('<div class="set-role-server">'
								+ '<div class="visson-role">'
								+ '<label class="from-note role">ROLES</label>'
								+'<i class="fas fa-plus setting new-role role"></i>'
								+ '<div class="list-role">'								
								+'</div>'
								+ '</div>'
								+ '</div>'
								+ '<div class="data-info serversetting">'
								+ '<div class="member-edit">'
								+ '<div class="name-role">'
								+ '<label class="from-note">ROLE NAME</label> <input type="text" class="new-name-role" id="namerole" name="namerole">'
								+ '</div>'
								+ '<label class="header-setting">GENERAL PERMISSIONS</label>'
								+ '<div class="detail-setting">'
								+ '<label class="from-note setting-detail">Administrator</label>'
								+ ' <label class="switch"> <input type="checkbox" class="oncolor">'
								+ '<span class="slider round"></span>'
								+ '</label>' + '</div>' + '</div>' + '</div>'
								+'<footer class="toolbar"></footer>');
						display.innerHTML = put;
						rolesServer = ""
							var displayRole = $('.list-role');
							var toolbar = $('.toolbar');
							var setnamerole = $('.name-role');
							$.ajax({
								url : "/ListRoleServer",
								type : 'POST',
								dataType : 'json',
								data : '',
								processData : false,
								beforeSend : function(xhr) {
									xhr.setRequestHeader(header, token);
								},
								success : function(data) {
									rolesServer = data.roleserver;
									var allrole = "";
									if (rolesServer) {
										for (var i = 0; i < rolesServer.length; i++) {
											allrole += '<label class="from-note rolenote small" name-data="'+rolesServer[i].role+'" data-id="'+rolesServer[i].id+'">' + "@"
													+ rolesServer[i].role + '</label>'
										}
										displayRole.html(allrole);
										$('.rolenote').on("click", function(){
											var setcommit="";
											setcommit=('<div class="footer-content save-file"><button class="btn color saverole" type="submit">Save Changes</button>'
											      		+'<button class="btn color-reset" type="submit">Reset</button></div>');
											toolbar.html(setcommit);
											var newrole='';
											var dataname =$(this).attr('name-data');
											var setRole=$(this);
											console.log(setRole);
											newrole =('<label class="from-note">ROLE NAME</label> '
													+'<input type="text" class="new-name-role" id="namerole" placeholder="'+dataname+'">');
											setnamerole.html(newrole);
											$('.saverole').on("click",function(){
												$.ajax({
													url : "/updateRole",
													type : 'POST',
													dataType : 'json',
													data : 'namerole='+ $('#namerole').val()+'&roleid='+setRole.attr("data-id") + '&serverid=' + $('.serverid').attr("data-id"),
													processData : false,
													beforeSend : function(xhr) {
														xhr.setRequestHeader(header, token);
													},
													success : function(data) {
													rolesServer = data.roleserver;
													var allrole = "";
													allrole = ('<label class="from-note rolenote small" name-data="'+rolesServer[0].role+'">' + "@"
															+ rolesServer[0].role + '</label>');
													displayRole.append(allrole);
													}
												})
											})
										})
									}
								}
							})
					}
					function Member() {
						put = ('<div class="data-member">'
								+ '<label class="from-note header">SERVER MEMBERS</label>'
								+ '<div class="all-members">'
								+ '<div id="number-member">'
								+ '<label class="from-note small"></label>'
								+ '</div>'
								+ '<label class="from-note small space">Member</label>'
								+ ' <label class="role space">Display role:</label>'
								+ '<div class="role control"></div>' + '</div>'
								+ '<div class="list-members" id="list-members"></div></div>');
						display.innerHTML = put;
					}
					Role();
					/*$.ajax({
						url : '/server-setting/' + serverid,
						type : 'POST',
						data : '',
						processData : false,
						contentType : "application/json",
						dataType : 'json',
						cache : false,
						beforeSend : function(xhr) {
							xhr.setRequestHeader(header, token);
						},
						success : function(data) {
							var result = ('<label class="serverid" data-id="'
									+ data + '">')
							controll.append(result);
						}
					})*/
				})