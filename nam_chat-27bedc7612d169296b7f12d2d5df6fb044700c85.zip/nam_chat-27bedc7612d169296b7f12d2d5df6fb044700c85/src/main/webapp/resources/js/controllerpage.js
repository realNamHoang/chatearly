$(document).ready(function() {
	var token = $('#_csrf').attr('content');
	var header = $('#_csrf_header').attr('content');
	var upload = document.getElementById("matchbox");
	var file = document.getElementById("file");
	$('.data-file').on('drop' ,function (e){
		e.preventDefault();
		var image = e.originalEvent.dataTransfer.files;
		var formImage= new FormData();
		var groupid = $('.channelid').attr("data-id");
		formImage.append('image',image[0]);
		formImage.append('channelid',groupid);
		uploadFromData(formImage);
	});
	function uploadFromData(formImage){
		$.ajax({
			url:'/sendImageMessages',
			type:'POST',
			data :formImage,
			processData : false,
			contentType : false,
			cache: false,
			beforeSend : function(xhr) {
				xhr.setRequestHeader(header, token);
			},
			success : function(data) {
				console.log("in");
			}
		});
	}
	$('.data-file').on('dragover' ,function (e){
		e.preventDefault();
		e.stopPropagation();
	})
	upload.addEventListener('click',function(){
		file.click();
		if ($('#file').get(0).files.length != 0) {
			var image = $('#file').get(0).files;
			var formImage= new FormData();
			var groupid = $('.channelid').attr("data-id");
			formImage.append('image',image[0]);
			formImage.append('channelid',groupid);
			uploadFromData(formImage);
			console.log(image[0].type);
			console.log(formImage);
		}
	})
});