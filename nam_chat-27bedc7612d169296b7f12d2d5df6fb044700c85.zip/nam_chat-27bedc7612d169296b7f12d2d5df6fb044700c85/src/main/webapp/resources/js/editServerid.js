$(document).ready(
		function() {
			var token = $('#_csrf').attr('content');
			var header = $('#_csrf_header').attr('content');
			$.ajax({
				url : '/setMemory',
				type : 'POST',
				dataType : 'json',
				data : '',
				processData : false,
				contentType : 'application/json',
				beforeSend : function(xhr) {
					xhr.setRequestHeader(header, token);
				},
				success : function(data) {
					var display = document.getElementById("userinfo");
					var result = data;
					var dataout = (' <label class="serverid" data-id="'
							+ result + '"></label>');
					display.innerHTML = dataout;
				}
			})
		})