$(document).ready(function() {
	$(".newserver").mouseover(function() {
		$(this).css({
			'border-radius' : '36%',
		});
	})
	$(".newserver").mouseout(function() {
		$(this).css({
			'border-radius' : '100%',
		});
	})
});