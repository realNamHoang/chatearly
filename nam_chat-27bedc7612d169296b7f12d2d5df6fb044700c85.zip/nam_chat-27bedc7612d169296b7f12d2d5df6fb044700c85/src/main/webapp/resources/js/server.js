$(document).ready(function() {
			var file = $('.file');
			var serverslot = $(".add-new");
			var token = $('#_csrf').attr('content');
			var header = $('#_csrf_header').attr('content');
			var servername = $('.saveserver');
			$(".userimage").on("click",	function() {
					file.click();
					$('.saveserver').on("click",function() {
						if ($('.file').get(0).files.length != 0) {
							var image = $('.file').get(0).files;
							var formImage= new FormData();
							var nameserver=$('#nameserver').serializeArray();
							$.each( nameserver , function(key,input){
								formImage.append(input.name,input.value);
							});
							formImage.append('image',image[0]);
							uploadFromData(formImage);
							}
						})
					})
			function uploadFromData(formImage) {
				$.ajax({
					url : '/creatnewserver',
					type : 'POST',
					data : formImage,
					processData : false,
					contentType : false,
					cache : false,
					beforeSend : function(xhr) {
						xhr.setRequestHeader(header, token);
					},
					success : function(data) {
					var result = data.servers;
					var datareturn = ('<div class="card-body contacts_body">'
										+ '<div class="d-flex bd-highlight">'
										+ '<div class="img_cont">'
										+ '<a href="${contextPath}/'
										+ result[0].serverid
										+ '"> '
										+ '<img class="user_img" src=/resources/image/'
										+ result[0].serverimage
										+ ' alt="" aria-hidden="true" width="48" height="48">'
										+ '</a>' + '</div>' + '</div>' + '</div>');
							serverslot.before(datareturn);
						}
				});
			}
	$.ajax({
		url : '/listserver',
		type : 'POST',
		data : '',
		processData : false,
		contentType : false,
		cache : false,
		beforeSend : function(xhr) {
			xhr.setRequestHeader(header, token);
		},
		success : function(data) {
		var result = data.servers;
		for (var i = 0; i < result.length; i++) {
			if (result[i].serverid != null){
			var datareturn = ('<div class="card-body contacts_body">'
								+ '<div class="d-flex bd-highlight">'
								+ '<div class="img_cont">'
								+ '<a class="server">'
								+ '<label class="idserver" data-id="'+result[i].serverid+'">'
								+ '<img  class="user_img" src=/resources/image/'
								+ result[i].serverimage
								+ ' alt=""  aria-hidden="true" width="48" height="48">'
								+ '</a>' + '</div>' + '</div>' + '</div>');
						serverslot.before(datareturn);
					}
				}
			}
		})
	$(".setserver").on("click",function() {
		$.ajax({
				url : '/groupMemory',
				type : 'POST',
				dataType : 'json',
				data : 'serverid=' + $('.serverid').attr("data-id"),
				processData : false,
				beforeSend : function(xhr) {
					xhr.setRequestHeader(header, token);
				},
				success : function(data) {
					console.log("done");
				}
			})
		})
	})