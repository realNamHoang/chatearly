$(document).ready(
		function() {
			var token = $('#_csrf').attr('content');
			var header = $('#_csrf_header').attr('content');
			$(".savechannel").on(
					"click",
					function() {
						$.ajax({
							url : '/creatnewchannel',
							type : 'POST',
							dataType : 'json',
							data : $('#namechannel').serialize() + '&serverid='
									+ $('.serverid').attr("data-id"),
							processData : false,
							beforeSend : function(xhr) {
								xhr.setRequestHeader(header, token);
							},
							success : function(data) {
								var result = data.channel;
								var display = $('.first-set');
								var datachannel = "";
								for (var i = 0; i < result.length; i++) {
									datachannel +=('<label class="from-note channel-detail detail " server-id="'+result[i].channelId+'">'
											+ '<i class="fas fa-hashtag detail-channel"></i>'
											+result[i].namechannel+'</label>');
								}
								display.append(datachannel);
							}
						})
					})
			$.ajax({
				url : '/listchannel',
				type : 'POST',
				dataType : 'json',
				data : 'serverid=' + $('.serverid').attr("data-id"),
				processData : false,
				beforeSend : function(xhr) {
					xhr.setRequestHeader(header, token);
				},
				success : function(data) {
					var result = data.channel;
					var display = $('.first-set');
					var datachannel = "";
					for (var i = 0; i < result.length; i++) {
						datachannel +=('<label class="from-note channel-detail detail " server-id="'+result[i].channelId+'">'
								+ '<i class="fas fa-hashtag detail-channel"></i>'
								+result[i].namechannel+'</label>');
					}
					display.append(datachannel);
					$('.channel-detail').on("click",function(){
						var groupid = $(this).attr('server-id');
								$.ajax({
									url : "/mappingChannel",
									type : 'POST',
									dataType : 'json',
									data : 'serverid='+ groupid,
									processData : false,
									beforeSend : function(xhr) {
										xhr.setRequestHeader(header, token);
									},
									success : function(data) {
										var message =data.messagesresult;
										var messageout=document.getElementById("messagelist");
										var messagelist="";
										var serverid=document.getElementById("setchannelid");
										var server="";
										for(var i=0;i<message.length;i++){
											if (message[i].sessionimage != null){
												messagelist +=('<div class="layout-tool">'
															+ '<label class="from-note">'
															+ message[i].userchat
															+ '</label>'
															+'<div class="messages">'
															+'<img class="imagemessages" src=/resources/image/'+message[i].sessionimage+'>'
															+'</div>'
															+'<div class="messageborder">'
															+'</div>'
															+'</div>');
												} if(message[i].session != null){
												messagelist +=('<div class="layout-tool">'
															+ '<label class="from-note">'
															+ message[i].userchat
															+ '</label>'
															+'<div class="messages">'
															+ message[i].session
															+'</div>'
															+'<div class="messageborder">'
															+'</div>'
															+'</div>');
													}
												}
											messageout.innerHTML=messagelist;
											server +=('<label class="channelid" data-id="'+groupid+'">'+'</label>');
											serverid.innerHTML=server;
											var bottom =$('.message-list');
											var height =bottom.get(0).scrollHeight;
											bottom.animate({scrollTop: height}); 
								}
							})
						})
				}
			})
		});