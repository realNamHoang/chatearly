$(document).ready(
		function() {
			var token = $('#_csrf').attr('content');
			var header = $('#_csrf_header').attr('content');
			var allmember="";
			var role=$('.role');
			$('.Members').on("click",function() {
			$.ajax({
				url : "/totalMember",
				type : 'POST',
				dataType : 'json',
				data : 'serverid=' + $('.serverid').attr("data-id"),
				processData : false,
				beforeSend : function(xhr) {
					xhr.setRequestHeader(header, token);
				},
				success : function(data) {
					allmember = data.member;
					var displaymember = document.getElementById('number-member');
					var membernumber = "";
					if (allmember) {
						membernumber = '<label class="from-note small">'
								+ allmember + '</label>';
					}
					displaymember.innerHTML = membernumber;
				}
			})
			$.ajax({
				url : "/listmemberprofile",
				type : 'POST',
				dataType : 'json',
				data : 'serverid=' + $('.serverid').attr("data-id"),
				processData : false,
				beforeSend : function(xhr) {
					xhr.setRequestHeader(header, token);
				},
				success : function(data) {
					var listmember= document.getElementById('list-members');
					userprofile = data.users;
					roles =data.roleserver;
					numberrole=data.roles;
					var memberprofile = "";
					var rolesdata="";
					if (userprofile) {
						for(var i=0 ; i<userprofile.length ; i++){
							roleprofile ="";
							for(j=0 ; j<numberrole[i] ; j++){
								roleprofile +=('<label class="from-note small userrole">'+roles[j].role+'</label>');
							}
							if(userprofile[i].image!=null){
							memberprofile += ('<div class="userprofile"><image class="profileuser"src=/resources/image/'+userprofile[i].image+'>'
									+'<label class="from-note small" data-id="'+userprofile[i].id+'">'+userprofile[i].email+'</label>'
									+'<div class="memberrole">'
									+roleprofile
									+'</div>'+'</div>');
							}else{
								memberprofile += ('<div class="userprofile"><image class="profileuser" >'
										+'<label class="from-note small username" data-id="'+userprofile[i].id+'">'+userprofile[i].email+'</label>'
										+'<div class="memberrole">'
										+roleprofile+' <button type="button" class="dropdown-toggle addnewRoleUser" type="button"'
										+'id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true"'
										+'aria-expanded="false"><i class="fas fa-plus setting role"></i></button>'
										+'<div class="dropdown-menu setrole" aria-labelledby="dropdownMenu2">'
										+'<div class="setrolemember">'
									   	+'<input type=text class="findrole" name="rolename" id="'+userprofile[i].id+'">'
									   	+'<i class="fas fa-search"></i>'
									   	+'</div>'
									   	+'<div class="listrolemember">'
									   	+'</div>'
									   	+'</div>'
										+'</div>'+'</div>');
							}
						}
						listmember.innerHTML=memberprofile;
					$('.findrole').keyup(function(e) {
						var userid =$(this).attr("id");
						var groupid = $('.serverid').attr("data-id");
							$.ajax({
								url : '/ListServer',
								type : 'GET',
								dataType : 'json',
								data : $('.findrole').serialize()+'&serverid='+groupid,
								processData : false,
								beforeSend : function(xhr) {
									xhr.setRequestHeader(header, token);
								},
								success : function(data) {
									var dataout=data.roleserver;
									var roleout="";
									var roledisplay=$('.listrolemember')
									for(var i=0; i < dataout.length ; i++){
										roleout +='<div class="addroledata"><label class="from-note small addroledatanote" data-note="'+dataout[i].id+'">'
												+dataout[i].role+'</label></div>'
									}
									roledisplay.html(roleout);
									$('.addroledatanote').on("click",function(){
									var roleid = $(this).attr("data-note");
									$.ajax({
										url : '/addmemberRole',
										type : 'GET',
										dataType : 'json',
										data : 'serverid='+groupid+'&roleid='+roleid+'&userid='+userid,
										processData : false,
										beforeSend : function(xhr) {
											xhr.setRequestHeader(header, token);
										},
										success : function(data) {
											
										}
									})
								})
							}
						})
					})
				}
			}
		})
	})
})