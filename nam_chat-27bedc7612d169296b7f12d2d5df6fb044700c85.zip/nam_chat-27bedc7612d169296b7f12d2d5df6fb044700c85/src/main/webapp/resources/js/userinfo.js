$(document).ready(function(){
	var token = $('#_csrf').attr('content');
	var header = $('#_csrf_header').attr('content');
	$.ajax({
		url : "/infoUser",
		type : 'POST',
		data:'',
		dataType : 'json',
		processData : false,
		contentType : 'application/json',
		beforeSend : function(xhr) {
			xhr.setRequestHeader(header, token);
		},
		success : function(data) {
			var user = data.result;
			var imageuser=document.getElementById("userinfo");
			var setuser="";
			var imageUser=document.getElementById("usersinfo");
			var setUser="";
			var save=document.getElementById("savebutton");
			var setSave="";
			if(user[0].image!=null){
				setuser +=('<div class="layout-tool">'
							+ '<label class="from-note">'
							+'<image class="User-image" src=/resources/image/'+user[0].image+'>'
							+'</label>'
							+'</div>');
				setUser +=('<img src="" class="userimage">');
			}
			setSave+=('<button type="button" class="btn btn-primary conform">Saves</button>');
			imageuser.innerHTML=setuser;
			var username=document.getElementById("nameuser");
			var setusername="";
			var email=document.getElementById("email");
			var setemail="";
			if(user[0].username!=null){
				setusername +=('<label class="from-edits">'
							+user[0].username
							+'</label>');
			}
			setemail+=('<label class="from-edits">'
					+user[0].email
					+'</label>');
			username.innerHTML=setusername;
			email.innerHTML=setemail;
			$('.edit').on("click",function(){
				setusername=('<input class="edits-input" type="text" id="usernamedata" placeholder="'+user[0].username+'">');
				setemail=('<input type="email" path="email" class="form-control edits-input" autofocus="true" placeholder="'+user[0].email+'" id="emaildata"></input>');
				setSave=('<button type="button" class="btn btn-primary conform">Saves</button>');
				username.innerHTML=setusername;
				email.innerHTML=setemail;
				save.innerHTML=setSave;
				$('.conform').on("click",function(){
					console.log($('#emaildata').serialize());
					if($('#usernamedata').val()){
						$.ajax({
							url : "/updateUsername",
							type : 'GET',
							data: $('#usernamedata').val(),
							dataType : 'json',
							processData : false,
							contentType : 'application/json',
							beforeSend : function(xhr) {
								xhr.setRequestHeader(header, token);
							},
							success : function(data) {
								
							}
						})
					}
					if($('#emaildata').val().trim() != ''){
						$.ajax({
							url : "/updateEmail",
							type : 'GET',
							data: $('#emaildata').val(),
							dataType : 'json',
							processData : false,
							contentType : 'application/json',
							beforeSend : function(xhr) {
								xhr.setRequestHeader(header, token);
							},
							success : function(data) {
								
							}
						})
					}
				})
			})
			$('.User-image').on("click",function() {
				var header = document.getElementByClassName("header");
				header.innerHTML=('<div class="layout-tool"><label class="from-note">User:Edits</label></div>');
			})
			$('.from-note').on("click",function(){
				var showheader = $(this).attr('data-note');
				var header = document.getElementByClassName("header");
				header.innerHTML=('<div class="layout-tool"><label class="from-note">'+showheader+'</label></div>');
			})
		}
	})
})