$(document).ready(function() {
	console.log('ready');
	var token = $('#_csrf').attr('content');
	var header = $('#_csrf_header').attr('content');
	$('#setfriend').on("click",function(event) {
		console.log('ready');
		$.ajax({
			url : "/getid",
			type : 'GET',
			dataType : 'json',
			data : $('#getid'),
			processData : false,
			contentType : 'application/json',
			beforeSend : function(xhr) {
				xhr.setRequestHeader(header, token);
			},
			success : function(data) {
				console.log('ready');
			}
		})
	});
});