package com.hellokoding.auth.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "control_user_role")
public class Control_User_Role {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Long userid;

	private Long rolecustom;

	private Long serverid;
	
	private Long sortnumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserid() {
		return userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}

	public Long getRolecustom() {
		return rolecustom;
	}

	public void setRolecustom(Long rolecustom) {
		this.rolecustom = rolecustom;
	}

	public Long getServerid() {
		return serverid;
	}

	public void setServerid(Long serverid) {
		this.serverid = serverid;
	}

	public Long getSortnumber() {
		return sortnumber;
	}

	public void setSortnumber(Long sortnumber) {
		this.sortnumber = sortnumber;
	}
}
