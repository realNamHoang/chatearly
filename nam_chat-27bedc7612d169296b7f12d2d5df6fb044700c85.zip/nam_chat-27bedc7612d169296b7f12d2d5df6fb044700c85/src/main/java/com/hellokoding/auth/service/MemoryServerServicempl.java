package com.hellokoding.auth.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.MemoryServerResult;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.repository.MemoryServerRespoitory;

@Service
public class MemoryServerServicempl implements MemoryServerService {

	@Autowired
	private UserService userService;
	@Autowired
	private MemoryServerService memoryServerService;
	@Autowired
	private MemoryServerRespoitory memoryServerRespoitory;

	@Override
	public List<MemoryServerResult> findByUserid(Long currentuser) {
		// TODO Auto-generated method stub
		List<MemoryServerResult> result = new ArrayList<MemoryServerResult>();
		result = memoryServerRespoitory.findByUserid(currentuser);
		return result;
	}

	@Override
	public void updateSetting(Long serverid) {
		// TODO Auto-generated method stub
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		memoryServerRespoitory.updateMessages(serverid, currentUser.getId());
	}

	@Override
	public List<MemoryServerResult> findBySetting(Long serverid) {
		// TODO Auto-generated method stub
		List<MemoryServerResult> result = new ArrayList<MemoryServerResult>();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		result = memoryServerRespoitory.findBySetting(currentUser.getId(), serverid);
		return result;
	}

	@Override
	public void save(Long serverid) {
		// TODO Auto-generated method stub
		MemoryServerResult result = new MemoryServerResult();
		List<MemoryServerResult> check = new ArrayList<MemoryServerResult>();
		check = memoryServerService.findBySetting(serverid);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		if (check.size() == 0) {
			result.setGroupid(serverid);
			result.setUserid(currentUser.getId());
			memoryServerRespoitory.save(result);
		}
		List<MemoryServerResult> list = memoryServerRespoitory.findByUserid(currentUser.getId());
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getGroupid() != serverid) {
				memoryServerRespoitory.deleteById(list.get(i).getId());
			}
		}
	}
}
