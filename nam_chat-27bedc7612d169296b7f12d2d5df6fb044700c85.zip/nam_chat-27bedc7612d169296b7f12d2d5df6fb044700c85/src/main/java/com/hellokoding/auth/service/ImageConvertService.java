package com.hellokoding.auth.service;

import org.springframework.web.multipart.MultipartFile;

public interface ImageConvertService {
	String encodeImage(MultipartFile image, String imageConvert);

	String encodeAvatar(MultipartFile image, String imageConvert);
	
	String encodeEmoij(MultipartFile image, String imageConvert);
}
