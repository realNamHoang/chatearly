package com.hellokoding.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.hellokoding.auth.model.Friend;

@CrossOrigin(origins = "http://localhost:4200")
public interface FriendRespository extends JpaRepository<Friend, Long> {
	@Query(value = "SELECT u FROM Friend u WHERE u.userid = :id")
	List<Friend> findByUserId(@Param("id") long id);

	@Query(value = "SELECT u FROM Friend u WHERE u.friendid = :friendId and u.userid=:currentuser")
	List<Friend> findByErrorId(@Param("friendId") long friendId, @Param("currentuser") long currentuser);

	@Transactional
	@Modifying
	@Query(value = "UPDATE Friend u SET u.groupid = :group WHERE u.friendid = :friendId and u.userid=:currentuser ")
	void updateGroupId(@Param("group") long group, @Param("friendId") long friendId, @Param("currentuser") long currentuser);
}
