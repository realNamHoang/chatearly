package com.hellokoding.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hellokoding.auth.model.Control_User_Role;

public interface ControlUser_roleRespoitory extends JpaRepository<Control_User_Role, Long> {
	@Query(value = "Select u From Control_User_Role u Where u.userid= :currentid and u.serverid= :currentserver")
	List<Control_User_Role> findByUserId(@Param("currentid") Long currentid,
			@Param("currentserver") Long currentserver);

	@Query(value = "Select u From Control_User_Role u Where u.serverid= :currentserver")
	List<Control_User_Role> findByServerId(@Param("currentserver") Long currentserver);
}
