package com.hellokoding.auth.service;

import java.util.HashSet;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.User;
import com.hellokoding.auth.repository.RoleRepository;
import com.hellokoding.auth.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Override
	public void save(User user) {
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		user.setRoles(new HashSet<>(roleRepository.findAll()));
		userRepository.save(user);
	}

	@Override
	public User findByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	@Override
	public List<User> findByUserEmail(String email) {
		return userRepository.findByUserEmail(email);
	}

	@Override
	public User findmatchId(Long id) {
		// TODO Auto-generated method stub
		return userRepository.findmatchId(id);
	}

	@Override
	public void updateImageUser(long userid, String userimage) {
		// TODO Auto-generated method stub
		userRepository.updateImageUser(userid, userimage);
	}

	@Override
	public void updateUsername(long userid, String username) {
		// TODO Auto-generated method stub
		userRepository.updateUsername(userid, username);
	}

	@Override
	public void updateUserEmail(long userid, String email) {
		// TODO Auto-generated method stub
		userRepository.updateEmail(userid, email);
	}

}
