package com.hellokoding.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.hellokoding.auth.model.Channel;

public interface ChannelRespoitory extends JpaRepository<Channel, Long> {
	@Query(value = "Select u From Channel u Where u.serverId= :currentserverid")
	List<Channel> findchannel_in_Server(@Param("currentserverid") Long currentserverid);

	@Transactional
	@Modifying
	@Query(value = "UPDATE Channel u SET u.namechannel = :newname WHERE u.channelId = :currentchannel  ")
	void updateChannel(@Param("newname") String newname, @Param("currentchannel") Long currentchannel);
}
