package com.hellokoding.auth.web;

import java.net.URI;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.hellokoding.auth.model.TokenModel;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.service.UserService;
import com.hellokoding.auth.validator.JwtTokenProvider;
import com.hellokoding.auth.validator.UserValidator;

@RestController
public class AuthController {

	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private UserValidator userValidator;
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	@Autowired
	private UserService userService;
	@Autowired
    private UserDetailsService userDetailsService;

	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody User userForm) {
		TokenModel response = new TokenModel();
		UserDetails userDetails = userDetailsService.loadUserByUsername(userForm.getEmail());
		UsernamePasswordAuthenticationToken emailPasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, userForm.getPassword(), userDetails.getAuthorities());
		Authentication authentication = authenticationManager.authenticate(emailPasswordAuthenticationToken/*new UsernamePasswordAuthenticationToken(userForm.getEmail(), userForm.getPassword())*/);
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String jwt = jwtTokenProvider.generateToken(authentication);
		response.setAccessToken(jwt);
		return ResponseEntity.ok(response);
	}

	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody User userForm, BindingResult bindingResult) {
		userValidator.validate(userForm, bindingResult);
		if (bindingResult.hasErrors()) {
			return ResponseEntity.ok("registration");
		}
		userService.save(userForm);
		URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/api/users/{username}")
				.buildAndExpand(userForm.getUsername()).toUri();
		return ResponseEntity.created(location).body("User registered successfully");
	}
}
