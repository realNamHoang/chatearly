package com.hellokoding.auth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.Groups;
import com.hellokoding.auth.repository.GroupsRespository;

@Service
public class GroupsServicempl implements GroupsService {
	@Autowired
	private GroupsRespository groupsRespository;

	@Override
	public Groups findmatchgroup(long id, long currentid) {
		// TODO Auto-generated method stub
		return groupsRespository.findmatchgroup(id, currentid);
	}

	@Override
	public List<Groups> findusergroup(long id) {
		// TODO Auto-generated method stub
		return groupsRespository.findusergroup(id);
	}

	@Override
	public List<Groups> finddirectgroups(long id) {
		// TODO Auto-generated method stub
		return groupsRespository.finddirectgroup(id);
	}

}