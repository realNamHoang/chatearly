package com.hellokoding.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hellokoding.auth.model.Server;

public interface Server_RoleRespoitory extends JpaRepository<Server, Long> {
	@Query(value = "Select u From Server u Where u.serverid= :currentid")
	Server findByServerid(@Param("currentid") Long currentid);
	
	@Query(value = "SELECT u FROM Server u WHERE u.nameServer like concat('%',:nameserver,'%')")
	List<Server> findByNameServer(@Param("nameserver") String nameserver);
}
