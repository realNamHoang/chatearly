package com.hellokoding.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.hellokoding.auth.model.Message_Units;

public interface MessageUnitsRespository extends JpaRepository<Message_Units, Long> {

	@Query(value = "SELECT u FROM Message_Units u WHERE u.userid = :currentid and u.serverid= :channelid")
	Message_Units findMatchUserServer(@Param("currentid") long currentid, @Param("channelid") long channelid);

	@Transactional
	@Modifying(clearAutomatically = true, flushAutomatically = true)
	@Query(value = "UPDATE Message_Units u SET u.messages = :message WHERE u.userid = :currentid and u.serverid= :channelid ",nativeQuery = true)
	void updateMessagesUnit(@Param("message") long message, @Param("currentid") long currentid,
			@Param("channelid") long channelid);
}
