package com.hellokoding.auth.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.MessageTime;
import com.hellokoding.auth.model.Message_Units;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.repository.MessageUnitsRespository;
import com.hellokoding.auth.repository.MessagesTimeResponsitory;

@Service
public class MUnitServicempl implements MUnitService {

	@Autowired
	private MessageUnitsRespository mURespository;

	@Autowired
	private MessagesTimeResponsitory mtRespository;

	@Autowired
	private UserService userService;

	@Override
	public Message_Units findMatchUserServer(long severid) {
		// TODO Auto-generated method stub
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		return mURespository.findMatchUserServer(currentUser.getId(), severid);
	}

	@Override
	public void updateMessageUnits(long message, long id, long severid) {
		// TODO Auto-generated method stub
		mURespository.updateMessagesUnit(message, id, severid);
	}

	@Override
	public void save(Message_Units messageUnits) {
		// TODO Auto-generated method stub
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		messageUnits.setUserid(currentUser.getId());
		mURespository.save(messageUnits);
	}

	@Override
	public void save(MessageTime messageTime) {
		// TODO Auto-generated method stub
		mtRespository.save(messageTime);
	}

	@Override
	public MessageTime findByGroupId(long groupid) {
		// TODO Auto-generated method stub
		return mtRespository.findByGroupid(groupid);
	}

}
