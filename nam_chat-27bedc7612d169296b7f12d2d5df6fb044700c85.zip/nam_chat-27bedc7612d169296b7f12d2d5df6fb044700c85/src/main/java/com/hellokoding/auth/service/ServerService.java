package com.hellokoding.auth.service;

import java.util.List;

import com.hellokoding.auth.model.Server;

public interface ServerService {

	void save(Server server);

	List<Server> findByUser();
	
	List<Server> findByServerId(Long serverid);
	
	List<Server> findByNameServer(String ServerName);
}
