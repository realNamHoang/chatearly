package com.hellokoding.auth.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "server")
public class Groups {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Long userid;

	private Long Groupid;

	@OneToMany(mappedBy = "groups")
	private Set<Messages> messages;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserid() {
		return userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}

	public Set<Messages> getGroups() {
		return messages;
	}

	public void setGroups(Set<Messages> messages) {
		this.messages = messages;
	}

	public Long getGroupid() {
		return Groupid;
	}

	public void setGroupid(Long Groupid) {
		this.Groupid = Groupid;
	}

}
