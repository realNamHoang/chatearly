package com.hellokoding.auth.service;

import com.hellokoding.auth.model.MessageTime;
import com.hellokoding.auth.model.Message_Units;

public interface MUnitService {
	Message_Units findMatchUserServer(long severid);

	void updateMessageUnits(long message, long id, long severid);

	void save(Message_Units messageUnits);

	MessageTime findByGroupId(long groupid);

	void save(MessageTime messageTime);
}
