package com.hellokoding.auth.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class ImageConvertServicempl implements ImageConvertService {
	private static String MESSAGE_UPLOADED_FOLDER = "src/main/webapp/resources/image/MessageImage";
	private static String EMOIJ_UPLOADED_FOLDER = "src/main/webapp/resources/image/MessageImage";
	private static String AVATAR_UPLOADED_FOLDER = "src/main/webapp/resources/image/MessageImage";
	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public String encodeImage(MultipartFile image, String type) {
		// TODO Auto-generated method stub
		String imageConvert = null;
		try {
			byte[] bytes = image.getBytes();
			Path path = Paths.get(MESSAGE_UPLOADED_FOLDER + image.getOriginalFilename());
			Files.write(path, bytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error("Save error");
		}
		imageConvert = image.getOriginalFilename();
		return imageConvert;
	}

	@Override
	public String encodeAvatar(MultipartFile image, String imageConvert) {
		// TODO Auto-generated method stub
		String avatarConvert = null;
		try {
			byte[] bytes = image.getBytes();
			Path path = Paths.get(AVATAR_UPLOADED_FOLDER + image.getOriginalFilename());
			Files.write(path, bytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error("Save error");
		}
		avatarConvert = image.getOriginalFilename();
		return avatarConvert;
	}

	@Override
	public String encodeEmoij(MultipartFile image, String imageConvert) {
		// TODO Auto-generated method stub
		String emoijConvert = null;
		try {
			byte[] bytes = image.getBytes();
			Path path = Paths.get(EMOIJ_UPLOADED_FOLDER + image.getOriginalFilename());
			Files.write(path, bytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error("Save error");
		}
		emoijConvert = image.getOriginalFilename();
		return emoijConvert;
	}
}
