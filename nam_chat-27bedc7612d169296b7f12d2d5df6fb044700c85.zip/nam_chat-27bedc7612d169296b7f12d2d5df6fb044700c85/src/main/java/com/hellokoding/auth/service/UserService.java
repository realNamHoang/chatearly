package com.hellokoding.auth.service;

import java.util.List;

import com.hellokoding.auth.model.User;

public interface UserService {
	void save(User user);

	User findByEmail(String email);

	List<User> findByUserEmail(String email);

	User findmatchId(Long id);

	void updateImageUser(long userid, String userimage);

	void updateUsername(long userid, String username);

	void updateUserEmail(long userid,String email);
}
