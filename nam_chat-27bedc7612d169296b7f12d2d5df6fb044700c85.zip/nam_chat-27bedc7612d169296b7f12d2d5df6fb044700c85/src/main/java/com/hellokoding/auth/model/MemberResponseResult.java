package com.hellokoding.auth.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonView;
import com.hellokoding.auth.web.Views;

public class MemberResponseResult {
	@JsonView(Views.Public.class)
	List<Custom_Role> roleserver;

	@JsonView(Views.Public.class)
	List<User> users;

	@JsonView(Views.Public.class)
	List<Long> roles;

	public void setResultRole(List<Custom_Role> roleserver) {
		this.roleserver = roleserver;
	}

	public void setResultUser(List<User> users) {
		this.users = users;
	}

	public void setResultLong(List<Long> roles) {
		this.roles = roles;
	}
}
