package com.hellokoding.auth.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.Messages;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.repository.MessagesRespository;

@Service
public class ChatServicempl implements ChatService {
	@Autowired
	private UserService userService;

	@Autowired
	private MessagesRespository messageRespository;

	@Override
	public List<Messages> findByGroupid(long id) {
		// TODO Auto-generated method stub
		return messageRespository.findByGroupid(id);
	}

	@Override
	public void save(Messages message) {
		// TODO Auto-generated method stub
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		message.setUserchats(currentUser.getEmail());
		messageRespository.save(message);
	}

	@Override
	public List<Messages> getMessageIf(List<Messages> data, long i) {
		// TODO Auto-generated method stub
		data.removeIf(message -> (message.getSortnumber() > (data.size() - i)));
		data.removeIf(message -> (message.getSortnumber() < (data.size() - i - 10)));
		return data;
	}

	@Override
	public List<Messages> getMessageOutput(List<Messages> data, long i) {
		// TODO Auto-generated method stub
		data.removeIf(message -> (message.getSortnumber() > (data.size())));
		data.removeIf(message -> (message.getSortnumber() < (data.size() - i - 10)));
		return data;
	}

	@Override
	public void updateMessages(String message, String username, long groupid, long numberMessages) {
		// TODO Auto-generated method stub
		messageRespository.updateMessages(message, username, groupid, numberMessages);
	}

	@Override
	public void deleteMessages(long sortid, long groupid) {
		// TODO Auto-generated method stub
		messageRespository.DeleteMessages(sortid, groupid);
	}
}
