package com.hellokoding.auth.service;

import java.util.List;

import com.hellokoding.auth.model.MemoryServerResult;

public interface MemoryServerService {
	List<MemoryServerResult> findByUserid(Long currentuser);
	
	void updateSetting(Long serverid);
	
	List<MemoryServerResult> findBySetting(Long serverid);
	
	void save(Long serverid);
}
