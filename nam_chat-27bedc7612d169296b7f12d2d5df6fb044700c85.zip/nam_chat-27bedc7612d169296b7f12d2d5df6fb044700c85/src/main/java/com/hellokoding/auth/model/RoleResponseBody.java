package com.hellokoding.auth.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonView;
import com.hellokoding.auth.web.Views;

public class RoleResponseBody {
	@JsonView(Views.Public.class)
	Long member;

	@JsonView(Views.Public.class)
	List<User_Role_Server> userserver;

	@JsonView(Views.Public.class)
	List<Server> servers;

	@JsonView(Views.Public.class)
	List<Channel> channel;

	@JsonView(Views.Public.class)
	List<Control_User_Role> userrole;

	@JsonView(Views.Public.class)
	List<Custom_Role> roleserver;

	public void setResultMember(long member) {
		this.member = member;
	}

	public void setResultDetailUser(List<User_Role_Server> userserver) {
		this.userserver = userserver;
	}

	public void setResultServer(List<Server> servers) {
		this.servers = servers;
	}

	public void setResultChannel(List<Channel> channel) {
		this.channel = channel;
	}

	public void setResultUserRole(List<Control_User_Role> userrole) {
		this.userrole = userrole;
	}

	public void setResultRole(List<Custom_Role> roleserver) {
		this.roleserver = roleserver;
	}
}
