package com.hellokoding.auth.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.Friend;
import com.hellokoding.auth.model.FriendResponseBody;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.service.FriendService;
import com.hellokoding.auth.service.UserService;

@RestController
public class FriendController {
	@Autowired
	private FriendService friendService;
	@Autowired
	private UserService userService;

	@ResponseBody
	@RequestMapping(value = "/getid")
	public AjaxResponseBody getidfriend(@RequestBody long getid) {
		AjaxResponseBody result = new AjaxResponseBody();
		Friend friend = new Friend();
		friend.setFriendid(getid);
		friendService.save(friend);
		List<User> newfriend = new ArrayList<User>();
		User users = userService.findmatchId(friend.getFriendid());
		newfriend.add(users);
		result.setResult(newfriend);
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/listFriend")
	public List<FriendResponseBody> ListFriend() {
		List<FriendResponseBody> resultfriend = new ArrayList<FriendResponseBody>();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		List<Friend> friendlist = friendService.findByUserId(currentUser.getId());
		List<User> friends = new ArrayList<User>();
		for (int i = 0; i < friendlist.size(); i++) {
			User users = userService.findmatchId(friendlist.get(i).getFriendid());
			friends.add(i, users);
			FriendResponseBody newResponse = new FriendResponseBody();
			newResponse.setFriendResult(friendlist.get(i));
			newResponse.setResult(users);
			resultfriend.add(i, newResponse);
		}
		return resultfriend;
	}

}
