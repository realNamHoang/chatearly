package com.hellokoding.auth.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.FriendResponseBody;
import com.hellokoding.auth.model.Groups;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.service.DirectService;
import com.hellokoding.auth.service.GroupsService;
import com.hellokoding.auth.service.UserService;

@RestController
public class DirectMessagesController {
	@Autowired
	private GroupsService groupSevice;
	@Autowired
	private DirectService directSevice;
	@Autowired
	private UserService userService;

	@ResponseBody
	@RequestMapping(value = "/mappingDM")
	public AjaxResponseBody getgroup(@RequestBody String friendemail, @RequestBody long channelid) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		User frienduser = userService.findByEmail(friendemail);
		AjaxResponseBody result = new AjaxResponseBody();
		Groups groups = groupSevice.findmatchgroup(channelid, frienduser.getId());
		directSevice.getDirectGroups(frienduser, groups, currentUser, result);
		return result;
	}
	
	@RequestMapping(value = "/FriendDetail")
	public AjaxResponseBody getFriendDetial(@RequestBody Long friendid) {
		AjaxResponseBody result = new AjaxResponseBody();
		User friendUser = userService.findmatchId(friendid);
		List<User> friend = new ArrayList<User>(); 
		friend.add(friendUser);
		result.setResult(friend);
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/setgroups")
	public FriendResponseBody setupgroup(@RequestBody long getid) {
		FriendResponseBody newfriendback = new FriendResponseBody();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		User friendemail = userService.findmatchId(getid);
		directSevice.setDirectGroups(friendemail.getEmail(), currentUser , newfriendback);
		return newfriendback;
	}
}
