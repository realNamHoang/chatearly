package com.hellokoding.auth.service;

import java.util.List;
import com.hellokoding.auth.model.Messages;

public interface ChatService {
	List<Messages> findByGroupid(long id);

	void save(Messages message);

	List<Messages> getMessageIf(List<Messages> data, long i);

	List<Messages> getMessageOutput(List<Messages> data, long i);

	void updateMessages(String message, String username, long groupid, long numberMessages);

	void deleteMessages(long sortid, long groupid);
}
