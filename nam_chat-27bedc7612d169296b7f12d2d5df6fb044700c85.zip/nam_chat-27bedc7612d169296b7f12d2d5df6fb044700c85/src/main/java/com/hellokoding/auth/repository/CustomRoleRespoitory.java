package com.hellokoding.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.hellokoding.auth.model.Custom_Role;

public interface CustomRoleRespoitory extends JpaRepository<Custom_Role, Long> {
	@Query(value = "Select u From Custom_Role u Where u.serverid= :currentserver")
	List<Custom_Role> findByServerId(@Param("currentserver") Long currentserver);

	@Query(value = "Select u From Custom_Role u Where u.serverid= :currentserver and u.role like concat('%',:rule,'%')")
	List<Custom_Role> findMatchRole(@Param("currentserver") Long currentserver, @Param("rule") String rule);
	
	@Query(value = "Select u From Custom_Role u Where u.id= :currentid")
	Custom_Role findByRoleId(@Param("currentid") Long currentid);

	@Transactional
	@Modifying
	@Query(value = "UPDATE Custom_Role u SET u.role = :upgraderole WHERE u.id = :roleid")
	void updateRole(@Param("roleid") long roleid, @Param("upgraderole") String upgraderole);
}
