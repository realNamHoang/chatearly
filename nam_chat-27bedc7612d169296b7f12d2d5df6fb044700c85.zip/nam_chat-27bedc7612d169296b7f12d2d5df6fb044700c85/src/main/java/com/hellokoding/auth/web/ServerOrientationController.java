package com.hellokoding.auth.web;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServerOrientationController {
	@RequestMapping(value = { "/server-setting/{serverid}" })
	public Long SetUserRole(@PathVariable(value = "serverid") Long serverid) {
		return serverid;
	}
}
