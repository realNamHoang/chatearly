package com.hellokoding.auth.model;

import java.util.List;

public class MessagesResult {
	private List<User> result;

	private List<Messages> messagesresult;

	private List<Friend> friendresult;

	public MessagesResult() {
	}

	public MessagesResult(List<User> result) {
		this.result = result;
	}

	public List<User> getResult() {
		return result;
	}

	public void setResult(List<User> result) {
		this.result = result;
	}

	public List<Messages> getMessagesresult() {
		return messagesresult;
	}

	public void setMessagesresult(List<Messages> messagesresult) {
		this.messagesresult = messagesresult;
	}

	public List<Friend> getFriendresult() {
		return friendresult;
	}

	public void setFriendresult(List<Friend> friendresult) {
		this.friendresult = friendresult;
	}

	public void setFriendResult(List<Friend> friend) {
		this.friendresult = friend;
	}
	
}
