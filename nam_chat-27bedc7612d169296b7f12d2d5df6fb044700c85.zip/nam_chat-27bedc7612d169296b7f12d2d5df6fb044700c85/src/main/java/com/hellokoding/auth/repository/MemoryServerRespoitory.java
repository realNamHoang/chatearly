package com.hellokoding.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.hellokoding.auth.model.MemoryServerResult;

public interface MemoryServerRespoitory extends JpaRepository<MemoryServerResult, Long> {
	@Modifying
	@Query(value = "Delete FROM MemoryServerResult u WHERE u.Groupid = :serverid and u.userid= :currentuser")
	void DeleteMessages(@Param("serverid") Long serverid, @Param("currentuser") Long currentuser);

	@Query(value = "SELECT u FROM MemoryServerResult u WHERE u.userid = :currentuser")
	List<MemoryServerResult> findByUserid(@Param("currentuser") Long currentuser);
	
	@Query(value = "SELECT u FROM MemoryServerResult u WHERE u.userid = :currentuser and u.Groupid = :serverid")
	List<MemoryServerResult> findBySetting(@Param("currentuser") Long currentuser,@Param("serverid") Long serverid);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE MemoryServerResult u SET u.Groupid = :serverid WHERE u.userid = :currentuser")
	void updateMessages(@Param("serverid") Long serverid, @Param("currentuser") Long currentuser);

}
