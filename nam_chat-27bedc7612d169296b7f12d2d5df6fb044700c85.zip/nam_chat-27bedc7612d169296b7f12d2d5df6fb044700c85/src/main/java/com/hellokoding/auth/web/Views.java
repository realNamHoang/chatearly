package com.hellokoding.auth.web;

public class Views {
	public static class Public {}
}
