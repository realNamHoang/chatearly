package com.hellokoding.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.hellokoding.auth.model.User_Role_Server;

public interface User_ServerResponsitory extends JpaRepository<User_Role_Server, Long> {
	@Query(value = "SELECT u FROM User_Role_Server u Where u.serverid= :currentserver")
	List<User_Role_Server> findByServerId(@Param("currentserver") long currentserver);

	@Query(value = "SELECT u FROM User_Role_Server u Where u.userid= :currentuser")
	List<User_Role_Server> findByUserId(@Param("currentuser") long currentuser);
	
	@Query(value = "SELECT u FROM User_Role_Server u Where u.userid= :currentuser and u.serverid= :currentserver")
	User_Role_Server findMatch(@Param("currentuser") long currentuser,@Param("currentserver") long currentserver);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE User_Role_Server u SET u.customroles = :numberrole WHERE u.userid= :currentuser and u.serverid= :currentserver")
	void updateRole(@Param("numberrole") Long numberrole, @Param("currentuser") Long currentuser,
			@Param("currentserver") Long currentserver);
}
