package com.hellokoding.auth.web;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.ResponseViewBody;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.service.ImageConvertService;
import com.hellokoding.auth.service.SecurityService;
import com.hellokoding.auth.service.UserService;
import com.hellokoding.auth.validator.UserValidator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class UserController {
	@Autowired
	private UserService userService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private UserValidator userValidator;

	@Autowired
	private ImageConvertService imageConvertService;

	@GetMapping(value = "/registration")
	public ResponseViewBody registration(Model model) {
		ResponseViewBody response = new ResponseViewBody();
		model.addAttribute("userForm", new User());
		response.setResponseBody("registration");

		return response;
	}

	@PostMapping(value = "/registration")
	public ResponseViewBody registration(@RequestBody User userForm, BindingResult bindingResult) {
		ResponseViewBody response = new ResponseViewBody();
		userValidator.validate(userForm, bindingResult);

		if (bindingResult.hasErrors()) {
			response.setResponseBody("registration");
			return response;
		}

		userService.save(userForm);

		securityService.autoLogin(userForm.getEmail(), userForm.getPasswordConfirm());

		response.setResponseBody("redirect:/welcome");

		return response;
	}

	@GetMapping(value = "/login", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseViewBody login(Model model, String error, String logout) {
		ResponseViewBody response = new ResponseViewBody();
		if (error != null)
			model.addAttribute("error", "Your email and password is invalid.");

		if (logout != null)
			model.addAttribute("message", "You have been logged out successfully.");
		response.setResponseBody("login");
		return response;
	}

	/*@GetMapping({ "/", "/welcome" })
	public ResponseViewBody welcome(Model model) {
		ResponseViewBody response = new ResponseViewBody();
		response.setResponseBody("welcome");
		return response;
	}*/
	
	
	@GetMapping({ "/", "/welcome" })
	public String welcome(Model model) {
		return "welcome";
	}

	@ResponseBody
	@RequestMapping(value = "/updateUsername")
	public AjaxResponseBody updateUser(@RequestBody String usernamedata) {
		AjaxResponseBody result = new AjaxResponseBody();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		userService.updateUsername(currentUser.getId(), usernamedata);
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/updateEmail")
	public AjaxResponseBody updateEmail(@RequestBody String emaildata) {
		AjaxResponseBody result = new AjaxResponseBody();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		userService.updateUsername(currentUser.getId(), emaildata);
		return result;
	}

	@ResponseBody
	@PostMapping(value = "/sendImageProfile")
	public void ImageProfile(@RequestBody MultipartFile image) {
		String imageencode = imageConvertService.encodeAvatar(image, "jpg");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		userService.updateImageUser(currentUser.getId(), imageencode);
	}

	@ResponseBody
	@RequestMapping(value = "/infoUser")
	public AjaxResponseBody UserInfo() {
		AjaxResponseBody result = new AjaxResponseBody();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		List<User> users = new ArrayList<>();
		users.add(currentUser);
		result.setResult(users);
		return result;
	}
}
