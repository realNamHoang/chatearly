package com.hellokoding.auth.service;

import java.util.List;

import com.hellokoding.auth.model.Groups;

public interface GroupsService {
	Groups findmatchgroup(long id, long currentid);

	List<Groups> finddirectgroups(long id);

	List<Groups> findusergroup(long id);
}
