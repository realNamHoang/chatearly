package com.hellokoding.auth.service;

import java.util.List;

import com.hellokoding.auth.model.Friend;

public interface FriendService {
	List<Friend> findByUserId(long id);

	void save(Friend friend);

	void updateDriectid(Friend friend);

	List<Friend> findByErrorId(long friendid, long currentuser);
}
