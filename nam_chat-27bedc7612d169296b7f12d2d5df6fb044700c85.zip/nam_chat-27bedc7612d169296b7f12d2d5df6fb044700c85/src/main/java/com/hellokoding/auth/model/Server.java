package com.hellokoding.auth.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "server_role")
public class Server {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Long serverid;

	private String serverimage;
	
	private String nameServer;
	
	private Long ruleChannel;
	
	@OneToMany
	@JoinColumn(name = "customrule")
	private Set<Custom_Role> customroles;

	@OneToMany
	@JoinColumn(name = "customchannel")
	private Set<Channel> customchannel;

	public enum basicRole {
		administrator, everyone, notification
	}

	public Long getServerid() {
		return serverid;
	}

	public void setServerid(Long serverid) {
		this.serverid = serverid;
	}

	public Set<Custom_Role> getRole() {
		return customroles;
	}

	public void setRole(Set<Custom_Role> customrule) {
		this.customroles = customrule;
	}

	public Set<Channel> getChannel() {
		return customchannel;
	}

	public void setChannel(Set<Channel> customchannel) {
		this.customchannel = customchannel;
	}

	public String getServerimage() {
		return serverimage;
	}

	public void setServerimage(String serverimage) {
		this.serverimage = serverimage;
	}

	public String getNameServer() {
		return nameServer;
	}

	public void setNameServer(String nameServer) {
		this.nameServer = nameServer;
	}

	public Long getRuleChannel() {
		return ruleChannel;
	}

	public void setRuleChannel(Long ruleChannel) {
		this.ruleChannel = ruleChannel;
	}
}
