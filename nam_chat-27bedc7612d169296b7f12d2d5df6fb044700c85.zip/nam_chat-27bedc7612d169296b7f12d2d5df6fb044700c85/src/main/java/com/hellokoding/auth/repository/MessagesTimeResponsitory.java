package com.hellokoding.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hellokoding.auth.model.MessageTime;

public interface MessagesTimeResponsitory extends JpaRepository<MessageTime, Long> {
	@Query(value = "SELECT u FROM MessageTime u WHERE u.serverid = :groupid")
	MessageTime findByGroupid(@Param("groupid") Long groupid);
}
