package com.hellokoding.auth.model;

import com.fasterxml.jackson.annotation.JsonView;
import com.hellokoding.auth.web.Views;

public class FriendResponseBody {
	@JsonView(Views.Public.class)
	User result;

	@JsonView(Views.Public.class)
	Messages messagesresult;

	@JsonView(Views.Public.class)
	Friend friendresult;

	public void setResult(User users) {
		// TODO Auto-generated method stub
		this.result = users;
	}

	public void setMessageResult(Messages message) {
		this.messagesresult = message;
	}

	public void setFriendResult(Friend friend) {
		this.friendresult = friend;
	}
}
