package com.hellokoding.auth.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.Server;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.model.User_Role_Server;
import com.hellokoding.auth.repository.ChannelRespoitory;
import com.hellokoding.auth.repository.FriendRespository;
import com.hellokoding.auth.repository.Server_RoleRespoitory;
import com.hellokoding.auth.repository.User_ServerResponsitory;

@Service
public class ServerServicempl implements ServerService {

	@Autowired
	private FriendRespository friendResponsitory;
	@Autowired
	private Server_RoleRespoitory role_serverRespoitory;
	@Autowired
	private ChannelRespoitory channelRespoitory;
	@Autowired
	private UserService userService;
	@Autowired
	private User_ServerResponsitory user_serverRespoitory;

	@Override
	public void save(Server server) {
		// TODO Auto-generated method stub
		long serverid = friendResponsitory.findAll().size() + role_serverRespoitory.findAll().size()
				+ channelRespoitory.findAll().size() + 1;
		server.setServerid(serverid);
		server.setRuleChannel(serverid + 2);
		role_serverRespoitory.save(server);
		User_Role_Server relation = new User_Role_Server();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		relation.setServerid(serverid);
		relation.setUserid(currentUser.getId());
		user_serverRespoitory.save(relation);
	}

	@Override
	public List<Server> findByUser() {
		// TODO Auto-generated method stub
		List<Server> serverUser = new ArrayList<Server>();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		List<User_Role_Server> listserver = user_serverRespoitory.findByUserId(currentUser.getId());
		for (int i = 0; i < listserver.size(); i++) {
			serverUser.add(role_serverRespoitory.findByServerid(listserver.get(i).getServerid()));
		}
		return serverUser;
	}

	public List<Server> joinServer(Long serverid) {
		List<Server> joinServer = new ArrayList<Server>();
		User_Role_Server set = new User_Role_Server();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		set.setServerid(serverid);
		set.setUserid(currentUser.getId());
		user_serverRespoitory.save(set);
		joinServer.add(role_serverRespoitory.findByServerid(serverid));
		return joinServer;
	}

	@Override
	public List<Server> findByServerId(Long serverid) {
		// TODO Auto-generated method stub
		List<Server> serverdetail = new ArrayList<Server>();
		serverdetail.add(role_serverRespoitory.findByServerid(serverid));
		return serverdetail;
	}

	@Override
	public List<Server> findByNameServer(String ServerName) {
		// TODO Auto-generated method stub
		return role_serverRespoitory.findByNameServer(ServerName);
	}
}
