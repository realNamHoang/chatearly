package com.hellokoding.auth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.Friend;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.repository.FriendRespository;

@Service
public class FriendServicempl implements FriendService {
	@Autowired
	private UserService userService;
	@Autowired
	private FriendRespository friendRespository;
	@Autowired
	private FriendService friendService;

	@Override
	public List<Friend> findByUserId(long id) {
		// TODO Auto-generated method stub
		return friendRespository.findByUserId(id);
	}

	@Override
	public void save(Friend friend) {
		// TODO Auto-generated method stub
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		friend.setUserid(currentUser.getId());
		friend.setGroupid((long) 0);
		List<Friend> findfrienderror = friendService.findByErrorId(friend.getFriendid(), friend.getUserid());
		if (findfrienderror.size() < 1) {
			friendRespository.save(friend);
		}
	}

	@Override
	public List<Friend> findByErrorId(long friendid, long currentuser) {
		// TODO Auto-generated method stub
		return friendRespository.findByErrorId(friendid, currentuser);
	}

	@Override
	public void updateDriectid(Friend friends) {
		// TODO Auto-generated method stub
		friendRespository.updateGroupId(friends.getGroupid(), friends.getFriendid(), friends.getUserid());
	}
}
