package com.hellokoding.auth.service;

import java.util.List;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.Channel;
import com.hellokoding.auth.model.User;

public interface ChannelService {
	void save(Channel channel);

	List<Channel> findchannel_in_Server(Long currentServerId);

	void updateChannel(String newname, Long currentchannel);

	void mappingChannel(Long serverid, User currentUser, AjaxResponseBody result);
	
	void saveNewServer(Long serverid);
}
