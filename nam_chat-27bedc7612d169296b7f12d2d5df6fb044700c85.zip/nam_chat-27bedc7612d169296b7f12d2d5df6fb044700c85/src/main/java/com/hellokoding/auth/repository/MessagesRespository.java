package com.hellokoding.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.hellokoding.auth.model.Messages;

public interface MessagesRespository extends JpaRepository<Messages, Long> {
	@Query(value = "SELECT u FROM Messages u WHERE u.groupid = :id")
	List<Messages> findByGroupid(@Param("id") Long id);

	@Transactional
	@Modifying
	@Query(value = "UPDATE Messages u SET u.session = :currentMessage WHERE u.userchats = :currentUser and u.groupid= :channelid and u.Sortnumber= :number")
	void updateMessages(@Param("currentMessage") String message, @Param("currentUser") String currentUser,
			@Param("channelid") Long channelid, @Param("number") Long number);

	@Modifying
	@Query(value = "Delete FROM Messages u WHERE u.Sortnumber = :sortid and u.groupid= :channelid")
	void DeleteMessages(@Param("sortid") Long sortid, @Param("channelid") Long channelid);

}
