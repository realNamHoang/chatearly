package com.hellokoding.auth.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.service.UserService;
import com.hellokoding.auth.validator.UserValidator;

@RestController
public class SearchUserController {
	@Autowired
	private UserService userService;
	@Autowired
	private UserValidator userValidator;
	List<User> users;

	@ResponseBody
	@RequestMapping(value = "/searchUser")
	public AjaxResponseBody getSearchResultViaAjax(@RequestBody String email) {

		AjaxResponseBody result = new AjaxResponseBody();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String emails = currentUserDetail.getUsername();
		if (!StringUtils.isEmpty(email)) {
			List<User> users = userService.findByUserEmail(email);
			userValidator.removesearchdata(users, emails);
			result.setResult(users);
		}
		return result;
	}
}