package com.hellokoding.auth.service;

import java.util.List;

import com.hellokoding.auth.model.Control_User_Role;
import com.hellokoding.auth.model.Custom_Role;
import com.hellokoding.auth.model.Server;
import com.hellokoding.auth.model.User_Role_Server;

public interface RoleService {
	List<Control_User_Role> findByUserId(Long currentid, Long currentserver);

	List<Control_User_Role> findWithServerId(Long currentserver);

	Server findByServerid(Long currentid);

	List<Custom_Role> findByServerId(Long currentserver);

	List<Custom_Role> findMatchRole(Long currentserver, String rule);

	Custom_Role findById(Long roleid);
	
	List<Custom_Role> findMatch(List<Control_User_Role> customrole);

	void updateRole(long roleid, String upgraderole);

	List<User_Role_Server> findByGroupId(long currentserver);

	List<User_Role_Server> findByUserId(long currentuser);

	void save(Custom_Role custom_Role);

	void save(Control_User_Role userrole);

	boolean check(Long serverid, String role, Long usersetid);

	void setCustomRoles(Long serverid, Long userid);

	void saveNewCustomServer(Long serverid,Long userid);
	
	void saveNewUserServer(Long serverid,Long userid);
}
