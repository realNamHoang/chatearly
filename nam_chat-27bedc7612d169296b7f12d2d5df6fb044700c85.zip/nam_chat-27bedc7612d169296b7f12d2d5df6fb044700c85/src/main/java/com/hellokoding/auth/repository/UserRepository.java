package com.hellokoding.auth.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import com.hellokoding.auth.model.User;


public interface UserRepository extends JpaRepository<User, Long> {
	User findByEmail(String email);

	@Query(value = "SELECT u FROM User u WHERE u.email like concat('%',:email,'%')")
	List<User> findByUserEmail(@Param("email") String email);

	List<User> findByEmailLike(String email);

	@Query(value = "SELECT u FROM User u WHERE u.id = :friendid")
	User findmatchId(@Param("friendid") Long friendid);

	@Transactional
	@Modifying
	@Query(value = "UPDATE User u SET u.image = :userimage WHERE u.id = :userid")
	void updateImageUser(@Param("userid") long userid, @Param("userimage") String userimage);

	@Transactional
	@Modifying
	@Query(value = "UPDATE User u SET u.username = :usernames WHERE u.id = :userid")
	void updateUsername(@Param("userid") long userid, @Param("usernames") String usernames);

	@Transactional
	@Modifying
	@Query(value = "UPDATE User u SET u.email = :useremail WHERE u.id = :userid")
	void updateEmail(@Param("userid") long userid, @Param("useremail") String useremail);
}
