package com.hellokoding.auth.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.Control_User_Role;
import com.hellokoding.auth.model.Custom_Role;
import com.hellokoding.auth.model.Server;
import com.hellokoding.auth.model.User_Role_Server;
import com.hellokoding.auth.repository.ControlUser_roleRespoitory;
import com.hellokoding.auth.repository.CustomRoleRespoitory;
import com.hellokoding.auth.repository.Server_RoleRespoitory;
import com.hellokoding.auth.repository.User_ServerResponsitory;

@Service
public class RoleServicempl implements RoleService {
	@Autowired
	private ControlUser_roleRespoitory controlUser_RoleRespoitory;
	@Autowired
	private Server_RoleRespoitory server_RoleRespoitory;
	@Autowired
	private CustomRoleRespoitory custom_RoleRespoitory;
	@Autowired
	private User_ServerResponsitory user_RoleRespoitory;

	@Override
	public List<Control_User_Role> findByUserId(Long currentid, Long currentserver) {
		// TODO Auto-generated method stub
		return controlUser_RoleRespoitory.findByUserId(currentid, currentserver);
	}

	@Override
	public Server findByServerid(Long currentid) {
		// TODO Auto-generated method stub
		return server_RoleRespoitory.findByServerid(currentid);
	}

	@Override
	public List<Custom_Role> findByServerId(Long currentserver) {
		// TODO Auto-generated method stub
		return custom_RoleRespoitory.findByServerId(currentserver);
	}

	@Override
	public void updateRole(long roleid, String upgraderole) {
		// TODO Auto-generated method stub
		custom_RoleRespoitory.updateRole(roleid, upgraderole);
	}

	@Override
	public List<User_Role_Server> findByGroupId(long currentserver) {
		// TODO Auto-generated method stub
		return user_RoleRespoitory.findByServerId(currentserver);
	}

	public List<User_Role_Server> findByUserId(long currentuser) {
		// TODO Auto-generated method stub
		return user_RoleRespoitory.findByUserId(currentuser);
	}

	@Override
	public void save(Custom_Role custom_Role) {
		// TODO Auto-generated method stub
		custom_RoleRespoitory.save(custom_Role);
	}

	@Override
	public boolean check(Long serverid, String role, Long usersetid) {
		// TODO Auto-generated method stub
		List<Custom_Role> roles = custom_RoleRespoitory.findMatchRole(serverid, role);
		Control_User_Role matchuserrole = new Control_User_Role();
		if (roles.size() != 0) {
			matchuserrole.setUserid(usersetid);
			matchuserrole.setRolecustom(roles.get(0).getId());
			controlUser_RoleRespoitory.save(matchuserrole);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public List<Custom_Role> findMatchRole(Long currentserver, String rule) {
		// TODO Auto-generated method stub
		return custom_RoleRespoitory.findMatchRole(currentserver, rule);
	}

	@Override
	public List<Control_User_Role> findWithServerId(Long currentserver) {
		// TODO Auto-generated method stub
		return controlUser_RoleRespoitory.findByServerId(currentserver);
	}

	public void save(Control_User_Role userrole) {
		controlUser_RoleRespoitory.save(userrole);
	}

	@Override
	public Custom_Role findById(Long roleid) {
		// TODO Auto-generated method stub
		return custom_RoleRespoitory.findByRoleId(roleid);
	}

	@Override
	public List<Custom_Role> findMatch(List<Control_User_Role> customrole) {
		// TODO Auto-generated method stub
		List<Custom_Role> roles = new ArrayList<Custom_Role>();
		if (customrole.size() != 0) {
			for (int j = 0; j < customrole.size(); j++) {
				roles.add(custom_RoleRespoitory.findByRoleId(customrole.get(j).getRolecustom()));
			}
		}
		return roles;
	}

	@Override
	public void setCustomRoles(Long serverid, Long userid) {
		// TODO Auto-generated method stub
		User_Role_Server findmatch = user_RoleRespoitory.findMatch(userid, serverid);
		user_RoleRespoitory.updateRole(findmatch.getCustomroles() + 1, userid, serverid);
	}

	@Override
	public void saveNewCustomServer(Long serverid, Long userid) {
		// TODO Auto-generated method stub
		Custom_Role roles = new Custom_Role();
		roles.setRole("admin");
		roles.setServerid(serverid);
		custom_RoleRespoitory.save(roles);
		Custom_Role role = new Custom_Role();
		role.setRole("everyone");
		role.setServerid(serverid);
		custom_RoleRespoitory.save(role);
		Control_User_Role newrule = new Control_User_Role();
		newrule.setRolecustom(roles.getId());
		newrule.setServerid(serverid);
		newrule.setUserid(userid);
		controlUser_RoleRespoitory.save(newrule);
		User_Role_Server userrole = new User_Role_Server();
		userrole.setUserid(userid);
		userrole.setCustomroles((long) 1);
		userrole.setServerid(serverid);
		user_RoleRespoitory.save(userrole);
	}

	@Override
	public void saveNewUserServer(Long serverid,Long userid) {
		// TODO Auto-generated method stub
		User_Role_Server userrole = new User_Role_Server();
		userrole.setUserid(userid);
		userrole.setCustomroles((long) 0);
		userrole.setServerid(serverid);
		user_RoleRespoitory.save(userrole);
	}
}
