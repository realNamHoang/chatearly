package com.hellokoding.auth.service;

public interface SecurityService {
    String findLoggedInEmail();

    void autoLogin(String email, String password);
}
