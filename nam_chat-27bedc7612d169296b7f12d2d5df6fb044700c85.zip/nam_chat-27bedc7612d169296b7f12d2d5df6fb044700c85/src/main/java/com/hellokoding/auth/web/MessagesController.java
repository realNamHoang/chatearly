package com.hellokoding.auth.web;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.Message_Units;
import com.hellokoding.auth.model.Messages;
import com.hellokoding.auth.repository.MessagesRespository;
import com.hellokoding.auth.service.ChatService;
import com.hellokoding.auth.service.ImageConvertService;
import com.hellokoding.auth.service.MUnitService;

@RestController
public class MessagesController {

	@Autowired
	private ChatService chatService;

	@Autowired
	private ImageConvertService imageConvertService;

	@Autowired
	private MUnitService munitService;
	
	@Autowired
	private MessagesRespository messageRespository;
	
	@ResponseBody
	@RequestMapping(value = "/listMessages")
	public AjaxResponseBody ListMessages(@RequestBody long groups) {
		AjaxResponseBody result = new AjaxResponseBody();
		List<Messages> messages = chatService.findByGroupid(groups);
		Message_Units setUp = new Message_Units();
		Message_Units check = new Message_Units();
		check = munitService.findMatchUserServer(groups);
		if (check == null) {
			setUp.setMessagesout((long) 0);
			setUp.setServerid(groups);
			munitService.save(setUp);
			chatService.getMessageOutput(messages, setUp.getMessagesout());
		} else {
			chatService.getMessageOutput(messages, 0);
		}
		result.setMessageResult(messages);
		return result;
	}

	@MessageMapping("/sendMessages")
	@SendTo("/friend/chatroom")
	public Messages setMessages(@Payload Messages message) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		message.setDatetime(dateFormat.format(date));
		message.setSortnumber((long) (chatService.findByGroupid(message.getGroupid()).size() + 1));
		messageRespository.save(message);
		return message;
	}

	@ResponseBody
	@RequestMapping(value = "/postMessages")
	public AjaxResponseBody setMessage(@RequestBody String data, @RequestBody long groups, AjaxResponseBody result) {
		Messages message = new Messages();
		message.setSession(data);
		message.setGroupid(groups);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		message.setDatetime(dateFormat.format(date));
		message.setSortnumber((long) (chatService.findByGroupid(groups).size() + 1));
		chatService.save(message);
		// MessageTime messagetime = munitService.findByGroupId(serverid);
		// DateFormat dateCheck = new SimpleDateFormat("yyyy/MM/dd");
		/*
		 * if (messagetime.getTimeset().compareTo(dateCheck.format(date)) != 0) {
		 * MessageTime newmessagetime = new MessageTime();
		 * newmessagetime.setServerid(serverid);
		 * newmessagetime.setTimeset(dateCheck.format(date));
		 * newmessagetime.setPremessages(message.getId()); }
		 */
		List<Messages> messages = new ArrayList<Messages>();
		messages.add(message);
		result.setMessageResult(messages);
		return result;
	}

	@ResponseBody
	@PostMapping(value = "/sendImageMessages")
	public void ImageMessages(@RequestParam MultipartFile image, @RequestBody long channelid) {
		Messages message = new Messages();
		String imageencode = imageConvertService.encodeImage(image, "jpg");
		message.setSessionimage(imageencode);
		message.setGroupid(channelid);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		message.setDatetime(dateFormat.format(date));
		message.setSortnumber((long) (chatService.findByGroupid(channelid).size() + 1));
		chatService.save(message);
	}

	@ResponseBody
	@RequestMapping(value = "/listnextMessages")
	public AjaxResponseBody nextMessages(@RequestBody long groups) {
		AjaxResponseBody result = new AjaxResponseBody();
		List<Messages> messages = chatService.findByGroupid(groups);
		Message_Units newmessages = new Message_Units();
		newmessages = munitService.findMatchUserServer(groups);
		if (messages.size() > (newmessages.getMessagesout() + 10)) {
			munitService.updateMessageUnits(newmessages.getMessagesout() + 10, newmessages.getUserid(), groups);
		} else {
			munitService.updateMessageUnits(messages.size(), newmessages.getUserid(), groups);
		}
		newmessages = munitService.findMatchUserServer(groups);
		chatService.getMessageIf(messages, newmessages.getMessagesout());
		result.setMessageResult(messages);
		return result;
	}
}
