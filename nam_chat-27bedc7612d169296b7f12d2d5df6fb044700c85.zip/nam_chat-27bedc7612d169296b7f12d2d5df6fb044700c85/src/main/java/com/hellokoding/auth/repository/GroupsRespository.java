package com.hellokoding.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hellokoding.auth.model.Groups;

public interface GroupsRespository extends JpaRepository<Groups, Long> {
	@Query(value = "SELECT u FROM Groups u WHERE u.Groupid = :id and u.userid=:currentid")
	Groups findmatchgroup(@Param("id") long id, @Param("currentid") long currentid);

	@Query(value = "SELECT u FROM Groups u WHERE u.Groupid = :id")
	List<Groups> finddirectgroup(@Param("id") long id);

	@Query(value = "SELECT u FROM Groups u WHERE u.userid= :uid")
	List<Groups> findusergroup(@Param("uid") long uid);
}
