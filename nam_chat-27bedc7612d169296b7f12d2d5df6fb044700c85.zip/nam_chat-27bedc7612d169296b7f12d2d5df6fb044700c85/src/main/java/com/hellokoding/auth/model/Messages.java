package com.hellokoding.auth.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "messages")
public class Messages {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String userchats;

	@ManyToOne
	private Groups groups;

	private Long groupid;

	private String session;

	private String sessionimage;

	private String datetime;
	
	private Long Sortnumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public Groups getGroups() {
		return groups;
	}

	public void setGroups(Groups groups) {
		this.groups = groups;
	}

	public String getUserchats() {
		return userchats;
	}

	public void setUserchats(String userchats) {
		this.userchats = userchats;
	}

	public Long getGroupid() {
		return groupid;
	}

	public void setGroupid(Long groupid) {
		this.groupid = groupid;
	}

	public String getSessionimage() {
		return sessionimage;
	}

	public void setSessionimage(String sessionimage) {
		this.sessionimage = sessionimage;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	public Long getSortnumber() {
		return Sortnumber;
	}

	public void setSortnumber(Long sortnumber) {
		this.Sortnumber = sortnumber;
	}
}
