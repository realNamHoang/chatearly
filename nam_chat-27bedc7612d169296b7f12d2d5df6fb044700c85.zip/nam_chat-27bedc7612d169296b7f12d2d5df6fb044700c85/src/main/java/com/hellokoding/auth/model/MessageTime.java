package com.hellokoding.auth.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "messageTime")
public class MessageTime {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String timeset;

	private Long serverid;
	
	private Long premessages;

	public Long getServerid() {
		return serverid;
	}

	public void setServerid(Long serverid) {
		this.serverid = serverid;
	}

	public String getTimeset() {
		return timeset;
	}

	public void setTimeset(String timeset) {
		this.timeset = timeset;
	}

	public Long getPremessages() {
		return premessages;
	}

	public void setPremessages(Long premessages) {
		this.premessages = premessages;
	}
}
