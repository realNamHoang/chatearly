package com.hellokoding.auth.service;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.FriendResponseBody;
import com.hellokoding.auth.model.Groups;
import com.hellokoding.auth.model.User;

public interface DirectService {
	void DirectMessages(long id);

	void setDirectGroups(String friendemail, User currentUser, FriendResponseBody newfriendback);

	void getDirectGroups(User frienduser, Groups groups, User currentUser,AjaxResponseBody result);
}
