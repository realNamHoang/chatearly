package com.hellokoding.auth.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.Channel;
import com.hellokoding.auth.model.MemoryServerResult;
import com.hellokoding.auth.model.RoleResponseBody;
import com.hellokoding.auth.model.Server;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.service.ChannelService;
import com.hellokoding.auth.service.ImageConvertService;
import com.hellokoding.auth.service.MemoryServerService;
import com.hellokoding.auth.service.RoleService;
import com.hellokoding.auth.service.ServerService;
import com.hellokoding.auth.service.UserService;

@RestController
public class ServerController {

	@Autowired
	private ImageConvertService imageConvertService;
	@Autowired
	private ServerService serverService;
	@Autowired
	private ChannelService channelService;
	@Autowired
	private MemoryServerService memoryServerService;
	@Autowired
	private UserService userService;
	@Autowired
	private RoleService roleService;

	@ResponseBody
	@PostMapping(value = "/creatnewserver")
	public RoleResponseBody newServer(@RequestParam MultipartFile image, @RequestBody String nameserver) {
		RoleResponseBody result = new RoleResponseBody();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		Server newServer = new Server();
		String imageencode = imageConvertService.encodeAvatar(image, "jpg");
		newServer.setServerimage(imageencode);
		newServer.setNameServer(nameserver);
		serverService.save(newServer);
		List<Server> servers = new ArrayList<Server>();
		servers.add(newServer);
		result.setResultServer(servers);
		channelService.saveNewServer(newServer.getServerid());
		roleService.saveNewCustomServer(newServer.getServerid(), currentUser.getId());
		return result;
	}

	@ResponseBody
	@PostMapping(value = "/creatnewchannel")
	public RoleResponseBody newChannel(@RequestBody String namechannel, @RequestBody Long serverid) {
		RoleResponseBody result = new RoleResponseBody();
		Channel channel = new Channel();
		channel.setNamechannel(namechannel);
		channel.setServerId(serverid);
		channelService.save(channel);
		List<Channel> listchannel = new ArrayList<Channel>();
		listchannel.add(channel);
		result.setResultChannel(listchannel);
		return result;
	}

	@ResponseBody
	@PostMapping(value = "/listchannel")
	public RoleResponseBody listChannel(@RequestBody Long serverid) {
		RoleResponseBody result = new RoleResponseBody();
		List<Channel> listchannel = channelService.findchannel_in_Server(serverid);
		result.setResultChannel(listchannel);
		return result;
	}

	@ResponseBody
	@PostMapping(value = "/listserver")
	public RoleResponseBody listServer() {
		RoleResponseBody result = new RoleResponseBody();
		List<Server> listserver = serverService.findByUser();
		result.setResultServer(listserver);
		return result;
	}

	@ResponseBody
	@PostMapping(value = "/findserver")
	public RoleResponseBody findServer(@RequestBody String servername) {
		RoleResponseBody result = new RoleResponseBody();
		List<Server> serverfound = serverService.findByNameServer(servername);
		result.setResultServer(serverfound);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		roleService.saveNewUserServer(serverfound.get(0).getServerid(), currentUser.getId());
		return result;
	}

	@ResponseBody
	@PostMapping(value = "/groupMemory")
	public void saveMemoryControll(@RequestBody Long serverid) {
		memoryServerService.save(serverid);
	}

	@ResponseBody
	@PostMapping(value = "/setMemory")
	public Long setMemory() {
		List<MemoryServerResult> result = new ArrayList<MemoryServerResult>();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		result = memoryServerService.findByUserid(currentUser.getId());
		return result.get(0).getGroupid();
	}

	@ResponseBody
	@PostMapping(value = "/mappingChannel")
	public AjaxResponseBody getChannel(@RequestBody Long serverid) {
		AjaxResponseBody result = new AjaxResponseBody();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		channelService.mappingChannel(serverid, currentUser, result);
		return result;
	}

	@ResponseBody
	@PostMapping(value = "/mappingControll")
	public AjaxResponseBody getDetail(@RequestBody Long serverid) {
		AjaxResponseBody result = new AjaxResponseBody();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		channelService.mappingChannel(serverid, currentUser, result);
		return result;
	}

}
