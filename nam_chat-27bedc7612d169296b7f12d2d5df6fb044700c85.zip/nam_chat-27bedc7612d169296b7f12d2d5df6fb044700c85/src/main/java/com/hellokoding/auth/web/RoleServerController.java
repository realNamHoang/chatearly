package com.hellokoding.auth.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hellokoding.auth.model.Control_User_Role;
import com.hellokoding.auth.model.Custom_Role;
import com.hellokoding.auth.model.MemberResponseResult;
import com.hellokoding.auth.model.MemoryServerResult;
import com.hellokoding.auth.model.RoleResponseBody;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.model.User_Role_Server;
import com.hellokoding.auth.service.MemoryServerService;
import com.hellokoding.auth.service.RoleService;
import com.hellokoding.auth.service.UserService;

@RestController
public class RoleServerController {
	@Autowired
	private RoleService roleService;
	@Autowired
	private UserService userService;
	@Autowired
	private MemoryServerService memoryServerService;

	@ResponseBody
	@RequestMapping(value = "/ListRoleServer")
	public RoleResponseBody ListRoleServer() {
		List<MemoryServerResult> serverresult = new ArrayList<MemoryServerResult>();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		org.springframework.security.core.userdetails.User currentUserDetail = (org.springframework.security.core.userdetails.User) authentication
				.getPrincipal();
		String email = currentUserDetail.getUsername();
		User currentUser = userService.findByEmail(email);
		serverresult = memoryServerService.findByUserid(currentUser.getId());
		RoleResponseBody result = new RoleResponseBody();
		List<Custom_Role> findmatch = roleService.findByServerId(serverresult.get(0).getGroupid());
		result.setResultRole(findmatch);
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/ListServer")
	public RoleResponseBody ListServer(Long serverid, String rolename) {
		RoleResponseBody result = new RoleResponseBody();
		List<Custom_Role> findmatch = roleService.findMatchRole(serverid, rolename);
		result.setResultRole(findmatch);
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/totalMember")
	public RoleResponseBody AllMember(@RequestBody Long serverid) {
		RoleResponseBody result = new RoleResponseBody();
		List<User_Role_Server> servermember = roleService.findByGroupId(serverid);
		result.setResultMember(servermember.size());
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/newRole")
	public RoleResponseBody SetNewRole(@RequestBody Long serverid, @RequestBody String namerole) {
		RoleResponseBody result = new RoleResponseBody();
		Custom_Role setrole = new Custom_Role();
		setrole.setRole(namerole);
		setrole.setServerid(serverid);
		roleService.save(setrole);
		List<Custom_Role> customrole = new ArrayList<Custom_Role>();
		customrole.add(setrole);
		result.setResultRole(customrole);
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/updateRole")
	public MemberResponseResult updateRole(@RequestBody Long serverid, @RequestBody Long roleid,
			@RequestParam String namerole) {
		MemberResponseResult result = new MemberResponseResult();
		List<Custom_Role> customrole = new ArrayList<Custom_Role>();
		roleService.updateRole(roleid, namerole);
		customrole = roleService.findMatchRole(serverid, namerole);
		result.setResultRole(customrole);
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/setNewUserRole")
	public void SetUserRole(@RequestBody Long serverid, @RequestBody String role, @RequestBody Long usersetid) {
		roleService.check(serverid, role, usersetid);
	}

	@ResponseBody
	@RequestMapping(value = "/listmemberprofile")
	public MemberResponseResult listmemberRole(@RequestBody Long serverid) {
		MemberResponseResult result = new MemberResponseResult();
		List<Control_User_Role> customrole = new ArrayList<Control_User_Role>();
		List<User_Role_Server> users = new ArrayList<User_Role_Server>();
		List<Custom_Role> roles = new ArrayList<Custom_Role>();
		List<User> usersprofile = new ArrayList<User>();
		List<Long> numberrole = new ArrayList<Long>();
		users = roleService.findByGroupId(serverid);
		for (int i = 0; i < users.size(); i++) {
			numberrole.add(users.get(i).getCustomroles());
			usersprofile.add(userService.findmatchId(users.get(i).getUserid()));
			customrole = roleService.findByUserId(users.get(i).getUserid(), serverid);
			roles = roleService.findMatch(customrole);
		}
		result.setResultRole(roles);
		result.setResultUser(usersprofile);
		result.setResultLong(numberrole);
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/addmemberRole")
	public RoleResponseBody addmemberRole(@RequestBody Long serverid, @RequestBody Long roleid,
			@RequestParam Long userid) {
		RoleResponseBody result = new RoleResponseBody();
		Control_User_Role roles = new Control_User_Role();
		roles.setServerid(serverid);
		roles.setRolecustom(roleid);
		roles.setUserid(userid);
		roleService.save(roles);
		roleService.setCustomRoles(serverid, userid);
		List<Custom_Role> customrole = new ArrayList<Custom_Role>();
		customrole.add(roleService.findById(roleid));
		result.setResultRole(customrole);
		return result;
	}
}
