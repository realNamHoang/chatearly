package com.hellokoding.auth.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonView;
import com.hellokoding.auth.web.Views;

public class AjaxResponseBody {
	@JsonView(Views.Public.class)
	List<User> result;

	@JsonView(Views.Public.class)
	List<Messages> messagesresult;

	@JsonView(Views.Public.class)
	List<Friend> friendresult;

	public void setResult(List<User> users) {
		// TODO Auto-generated method stub
		this.result = users;
	}

	public void setMessageResult(List<Messages> message) {
		this.messagesresult = message;
	}

	public void setFriendResult(List<Friend> friend) {
		this.friendresult = friend;
	}
}
