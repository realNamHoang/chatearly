package com.hellokoding.auth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.Channel;
import com.hellokoding.auth.model.Message_Units;
import com.hellokoding.auth.model.Messages;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.repository.ChannelRespoitory;
import com.hellokoding.auth.repository.GroupsRespository;
import com.hellokoding.auth.repository.Server_RoleRespoitory;

@Service
public class ChannelServicempl implements ChannelService {
	@Autowired
	private ChannelRespoitory channelRespoitory;
	@Autowired
	private GroupsRespository groupsRespository;
	@Autowired
	private Server_RoleRespoitory role_serverRespoitory;
	@Autowired
	private ChatService chatServive;
	@Autowired
	private MUnitService munitService;

	@Override
	public void save(Channel channel) {
		// TODO Auto-generated method stub
		long sortid = channelRespoitory.findAll().size() + groupsRespository.findAll().size() / 2
				+ role_serverRespoitory.findAll().size() + 1;
		channel.setChannelId(sortid);
		channelRespoitory.save(channel);
	}

	@Override
	public List<Channel> findchannel_in_Server(Long currentServerId) {
		// TODO Auto-generated method stub
		return channelRespoitory.findchannel_in_Server(currentServerId);
	}

	@Override
	public void updateChannel(String newname, Long currentchannel) {
		// TODO Auto-generated method stub
		channelRespoitory.updateChannel(newname, currentchannel);
	}

	@Override
	public void mappingChannel(Long serverid, User currentUser, AjaxResponseBody result) {
		// TODO Auto-generated method stub
		List<Messages> messages = chatServive.findByGroupid(serverid);
		chatServive.getMessageOutput(messages, 0);
		Message_Units check = new Message_Units();
		Message_Units setUp = new Message_Units();
		check = munitService.findMatchUserServer(serverid);
		if (check == null) {
			setUp.setMessagesout((long) 0);
			setUp.setServerid(serverid);
			munitService.save(setUp);
		} else {
			munitService.updateMessageUnits(0, currentUser.getId(), serverid);
		}
		result.setMessageResult(messages);
	}

	@Override
	public void saveNewServer(Long serverid) {
		// TODO Auto-generated method stub
		Channel channel = new Channel();
		channel.setNamechannel("general");
		channel.setServerId(serverid);
		channel.setChannelId(serverid + 1);
		Channel infochannel = new Channel();
		infochannel.setNamechannel("InfoServer");
		infochannel.setServerId(serverid);
		infochannel.setChannelId(serverid + 2);
		channelRespoitory.save(channel);
		channelRespoitory.save(infochannel);
	}

}
