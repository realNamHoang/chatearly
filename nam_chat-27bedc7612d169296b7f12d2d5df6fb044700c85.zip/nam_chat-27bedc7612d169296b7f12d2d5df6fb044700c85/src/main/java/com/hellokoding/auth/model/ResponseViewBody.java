package com.hellokoding.auth.model;

import com.fasterxml.jackson.annotation.JsonView;
import com.hellokoding.auth.web.Views;

public class ResponseViewBody {

	@JsonView(Views.Public.class)
	String response;

	public void setResponseBody(String response) {
		this.response = response;
	}
}
