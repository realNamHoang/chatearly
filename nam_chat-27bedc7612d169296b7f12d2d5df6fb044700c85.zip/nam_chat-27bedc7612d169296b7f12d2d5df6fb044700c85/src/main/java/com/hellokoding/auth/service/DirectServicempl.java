package com.hellokoding.auth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.model.AjaxResponseBody;
import com.hellokoding.auth.model.Friend;
import com.hellokoding.auth.model.FriendResponseBody;
import com.hellokoding.auth.model.Groups;
import com.hellokoding.auth.model.Message_Units;
import com.hellokoding.auth.model.Messages;
import com.hellokoding.auth.model.User;
import com.hellokoding.auth.repository.ChannelRespoitory;
import com.hellokoding.auth.repository.GroupsRespository;
import com.hellokoding.auth.repository.Server_RoleRespoitory;
import com.hellokoding.auth.web.MessagesController;

@Service
public class DirectServicempl implements DirectService {
	@Autowired
	private UserService userService;
	@Autowired
	private ChatService chatService;
	@Autowired
	private GroupsService groupSevice;
	@Autowired
	private FriendService friendService;
	@Autowired
	private GroupsRespository groupsRespository;
	@Autowired
	private MessagesController messagesController;
	@Autowired
	private MUnitService munitService;
	@Autowired
	private Server_RoleRespoitory server_roleRespoitory;
	@Autowired
	private ChannelRespoitory channelRespoitory;

	@Override
	public void DirectMessages(long id) {
		// TODO Auto-generated method stub
		messagesController.ListMessages(id);
	}

	@Override
	public void setDirectGroups(String friendemail, User currentUser, FriendResponseBody newfriendback) {
		// TODO Auto-generated method stub
		Groups groupsfriend = new Groups();
		Groups groupsuser = new Groups();
		Friend friends = new Friend();
		long groupid = groupsRespository.findAll().size() / 2 + server_roleRespoitory.findAll().size()
				+ channelRespoitory.findAll().size() + 1;
		User frienduser = userService.findByEmail(friendemail);
		newfriendback.setResult(frienduser);
		List<Friend> check = friendService.findByErrorId(currentUser.getId(), frienduser.getId());
		if (check.size() < 1) {
			groupsfriend.setUserid(frienduser.getId());
			groupsfriend.setGroupid(groupid);
			groupsuser.setUserid(currentUser.getId());
			groupsuser.setGroupid(groupid);
			groupsRespository.save(groupsfriend);
			groupsRespository.save(groupsuser);
			friends.setFriendid(frienduser.getId());
			friends.setGroupid(groupid);
			friends.setUserid(currentUser.getId());
			friendService.updateDriectid(friends);
			newfriendback.setFriendResult(friends);
		} else {
			friends.setFriendid(frienduser.getId());
			friends.setGroupid(check.get(0).getGroupid());
			friends.setUserid(currentUser.getId());
			friendService.updateDriectid(friends);
			newfriendback.setFriendResult(friends);
		}
	}

	@Override
	public void getDirectGroups(User frienduser, Groups groups, User currentUser, AjaxResponseBody result) {
		// TODO Auto-generated method stub
		Groups matchgroup = new Groups();
		matchgroup = groupSevice.findmatchgroup(groups.getGroupid(), currentUser.getId());
		List<Groups> users = groupSevice.finddirectgroups(matchgroup.getGroupid());
		List<Messages> messages = chatService.findByGroupid(matchgroup.getGroupid());
		chatService.getMessageOutput(messages, 0);
		Message_Units check = new Message_Units();
		Message_Units setUp = new Message_Units();
		check = munitService.findMatchUserServer(matchgroup.getGroupid());
		if (check == null) {
			setUp.setMessagesout((long) 0);
			setUp.setServerid(matchgroup.getGroupid());
			munitService.save(setUp);
		} else {
			munitService.updateMessageUnits(0, currentUser.getId(), matchgroup.getGroupid());
		}
		if (users.size() <= 2 && users.size() != 0) {
			result.setMessageResult(messages);
		}
	}
}
